# Changelog

## 0.1.0-beta.6
The line under "Knocking Ghost" at the top of the panel, and on the login screen, now reads "Sightings" instead of "Mori sightings".

## 0.1.0-beta.5
Each row in the list shows its pin icon at the right: the sticker icon for stickers, the ghost for other pieces, the X for planned spots, faded when a piece is gone.

## 0.1.0-beta.4
Activity list on the settings page: who logged in, who opened the map and when, plus wrong-password attempts.

- Each entry has the time, the person's name, and the kind of device (for example "iPhone · Safari"). Internet addresses are not stored.
- Opens by the same person on the same device within 30 minutes count once. The last 1000 entries are kept.
- The People table now shows when each person last opened the map.

## 0.1.0-beta.3
The settings page can show each person's password again (Show and Copy buttons in their row), and spaces typed before or after a password are ignored at login.

- Passwords set before this version cannot be shown until a new one is set for that person.
- The viewable copy is encrypted with a key made from the site's secret keys; logins still use the one-way code.

## 0.1.0-beta.2
No changes to how the map works. This build exists to confirm that updates arrive on the Plugins screen with one click.

## 0.1.0-beta.1
First build: view-only map at /sightings/ with a password-only login, one password per person (Settings → KG Sightings), reading the private map's pins, photos and look without being able to change them.

- Viewers see placed pieces only by default; planned spots, "gone" pieces, written addresses and notes are each a switch.
- Photos are sent only for pins the viewer is allowed to see.
- Removing a person or changing their password ends their logins at once.
- 8 wrong passwords from one address pause logins from it for 15 minutes.
- Self-updater (beta/stable channels, check-now, rollback) from the first version.
