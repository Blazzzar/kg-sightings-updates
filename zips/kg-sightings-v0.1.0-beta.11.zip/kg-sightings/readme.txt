=== KG Sightings ===
Contributors: chrisjennings
Requires at least: 5.5
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 0.1.0-beta.11

View-only version of the Knocking Ghost placement map, behind a password-only login with one password per person.

== What it does ==
* Serves a view-only map at /sightings/ (the address can be changed in the settings).
* Reads the pins, photos and look of the private map in public_html/map/. It never writes to that folder.
* Login is one password field, no username. Each person has their own password, set under Settings → KG Sightings.
* By default viewers see placed pieces only, without the date placed, the written address or your notes. Planned spots, "gone" pieces, dates, addresses and notes can each be switched on.

== Install ==
1. Plugins → Add New → Upload Plugin → choose the kg-sightings zip → Install Now → Activate.
2. Settings → KG Sightings → add a person (a name for your own reference, and their password).
3. Send them the address shown at the top of that page, and their password.
4. Once only: SiteGround Site Tools → Speed → Caching → Dynamic Cache → Exclude URLs → add /sightings/*

(No "Save Permalinks" step needed.)

== Update ==
KG Sightings updates itself from its own GitHub release channel. New builds appear as a normal
"update available" row on the Plugins screen. The plugin's row also has "Check for updates",
"Switch to beta/stable channel" and "Roll back to X".

== Good to know ==
* Each person's password can be shown again on the settings page (Show / Copy in their row). Anyone who can log in to wp-admin as an administrator can therefore read them. The stored copy is encrypted with the site's secret keys.
* The settings page has an Activity list: who logged in, who opened the map, and wrong-password attempts, with the time and the kind of device. Internet addresses are not stored.
* The password can be switched off (Settings → KG Sightings → Who can open the map). The map is then open to anyone with the address; it is still view-only.
* Each pin shows its town and state (for example "Chicago, IL"). These are worked out from the pin's position by OpenStreetMap's lookup service, once per pin, in the background, and can be switched off.
* Spaces typed before or after a password are ignored at login.
* Removing a person, or giving them a new password, logs out every browser they were logged in on.
* 8 wrong passwords from one internet address pause logins from that address for 15 minutes.
* If the site's secret keys in wp-config.php are ever changed, every password needs setting again.
