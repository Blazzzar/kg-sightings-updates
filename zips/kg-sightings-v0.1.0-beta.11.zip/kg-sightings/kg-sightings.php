<?php
/**
 * Plugin Name:       KG Sightings
 * Description:       View-only version of the Knocking Ghost placement map at /sightings/, behind a password-only login. Each person gets their own password, managed under Settings → KG Sightings. Reads the same data as the private map in /map/ and can never change it.
 * Version:           0.1.0-beta.11
 * Author:            Chris Jennings
 * Plugin URI:        https://github.com/Blazzzar/kg-sightings
 * Update URI:        https://blazzzar.github.io/kg-sightings-updates/kg-sightings.json
 * Requires at least: 5.5
 * Requires PHP:      7.4
 */

if (!defined('ABSPATH')) exit;

define('KGS_VERSION', '0.1.0-beta.11');
define('KGS_PLUGIN_FILE', __FILE__);
define('KGS_OPTION_PEOPLE', 'kgs_people');       // list of people: id, name, hash, enc, created, last_login, logins
define('KGS_OPTION_SETTINGS', 'kgs_settings');   // slug, map_dir, what viewers see, how long a login lasts
define('KGS_COOKIE', 'kgs_auth');
define('KGS_MAX_FAILS', 8);                      // wrong passwords allowed per address before a pause
define('KGS_LOCK_MINUTES', 15);

/* ============================================================
 * SELF-UPDATER — GitHub release channel (same pipeline as Chris's
 * other plugins). See includes/class-kgs-updater.php.
 * ============================================================ */
require_once __DIR__ . '/includes/class-kgs-updater.php';
require_once __DIR__ . '/includes/class-kgs-updater-admin.php';
KGS_Updater::instance();
KGS_Updater_Admin::init();

require_once __DIR__ . '/includes/kgs-data.php';
require_once __DIR__ . '/includes/kgs-log.php';
require_once __DIR__ . '/includes/kgs-places.php';
require_once __DIR__ . '/includes/kgs-admin.php';

/* ============================================================
 * SETTINGS + PEOPLE
 * ============================================================ */

function kgs_defaults() {
    return array(
        'slug'         => 'sightings',
        'map_dir'      => 'map',     // folder of the private map, relative to the WordPress root
        'show_planned' => 0,
        'show_gone'    => 0,
        'show_address' => 0,
        'show_notes'   => 0,
        'require_password' => 1, // 0 = anyone with the address can open the map
        'show_town'    => 1,     // town and state, e.g. "Chicago, IL"
        'show_date'    => 0,     // date and time a piece was placed
        'days'         => 30,        // how long a login lasts on one browser
    );
}

function kgs_settings() {
    $s = get_option(KGS_OPTION_SETTINGS, array());
    return array_merge(kgs_defaults(), is_array($s) ? $s : array());
}

function kgs_people() {
    $p = get_option(KGS_OPTION_PEOPLE, array());
    return is_array($p) ? $p : array();
}

/**
 * A password is never stored as typed. What is stored is this one-way
 * code made from the password and the site's secret keys (wp-config.php).
 * The same password always produces the same code, so a login can be
 * matched to its person without a username.
 */
function kgs_hash_password($password) {
    return hash_hmac('sha256', (string) $password, wp_salt('secure_auth'));
}

/**
 * A second, readable copy of each password is kept so the admin page can
 * show it again. It is encrypted with a key made from the site's secret
 * keys (wp-config.php), so the database on its own does not reveal it.
 * Logins never use this copy — they use the one-way code above.
 */
function kgs_view_key() {
    return hash('sha256', 'kgs-view|' . wp_salt('secure_auth'), true);
}
function kgs_encrypt_password($password) {
    if (!function_exists('openssl_encrypt')) return '';
    $iv  = random_bytes(12);
    $tag = '';
    $ct  = openssl_encrypt((string) $password, 'aes-256-gcm', kgs_view_key(), OPENSSL_RAW_DATA, $iv, $tag);
    return $ct === false ? '' : base64_encode($iv . $tag . $ct);
}
function kgs_decrypt_password($blob) {
    if (!function_exists('openssl_decrypt') || !is_string($blob) || $blob === '') return null;
    $raw = base64_decode($blob, true);
    if ($raw === false || strlen($raw) < 29) return null;
    $pt = openssl_decrypt(substr($raw, 28), 'aes-256-gcm', kgs_view_key(), OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16));
    return $pt === false ? null : $pt;
}

function kgs_find_person_by_password($password) {
    $hash = kgs_hash_password($password);
    $found = null;
    foreach (kgs_people() as $person) {       // compare against every entry (no early exit)
        if (!empty($person['hash']) && hash_equals((string) $person['hash'], $hash)) $found = $person;
    }
    return $found;
}

/* ============================================================
 * LOGIN COOKIE
 * value = <person id>.<expiry>.<signature>; the signature includes the
 * person's stored password code, so removing a person or changing their
 * password ends every login of theirs at once.
 * ============================================================ */

function kgs_sign($id, $exp, $hash) {
    return hash_hmac('sha256', $id . '|' . $exp . '|' . $hash, wp_salt('auth'));
}

function kgs_set_cookie($value, $expires) {
    setcookie(KGS_COOKIE, $value, array(
        'expires'  => $expires,
        'path'     => '/',
        'secure'   => is_ssl(),
        'httponly' => true,
        'samesite' => 'Lax',
    ));
}

/** The logged-in person for this request, or null. */
function kgs_current_person() {
    $raw = isset($_COOKIE[KGS_COOKIE]) ? (string) $_COOKIE[KGS_COOKIE] : '';
    $parts = explode('.', $raw);
    if (count($parts) !== 3) return null;
    list($id, $exp, $sig) = $parts;
    if (!ctype_digit($exp) || (int) $exp < time()) return null;
    foreach (kgs_people() as $person) {
        if ((string) $person['id'] === $id) {
            return hash_equals(kgs_sign($id, $exp, (string) $person['hash']), $sig) ? $person : null;
        }
    }
    return null;
}

/* ============================================================
 * WRONG-PASSWORD LIMIT (per visitor address)
 * ============================================================ */

function kgs_fail_key() {
    $ip = isset($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : 'unknown';
    return 'kgs_fail_' . md5($ip);
}
function kgs_is_locked() { return (int) get_transient(kgs_fail_key()) >= KGS_MAX_FAILS; }
function kgs_note_fail() { set_transient(kgs_fail_key(), (int) get_transient(kgs_fail_key()) + 1, KGS_LOCK_MINUTES * MINUTE_IN_SECONDS); }
function kgs_clear_fails() { delete_transient(kgs_fail_key()); }

/* ============================================================
 * ROUTING — /<slug>/ is answered here, before WordPress looks for a page.
 * No rewrite rules, so no "save permalinks" step.
 * ============================================================ */

function kgs_viewer_url() {
    $s = kgs_settings();
    return home_url('/' . $s['slug'] . '/');
}

function kgs_no_cache() {
    nocache_headers();
    header('X-Cache-Enabled: False');           // SiteGround's page cache skips responses carrying this
    header('X-Robots-Tag: noindex, nofollow');
    if (!defined('DONOTCACHEPAGE')) define('DONOTCACHEPAGE', true);
}

function kgs_json($data, $code = 200) {
    kgs_no_cache();
    status_header($code);
    header('Content-Type: application/json; charset=utf-8');
    echo wp_json_encode($data);
    exit;
}

add_action('init', 'kgs_route', 1);
function kgs_route() {
    if (is_admin() || (defined('DOING_CRON') && DOING_CRON) || (defined('WP_CLI') && WP_CLI)) return;
    $s    = kgs_settings();
    $path = (string) parse_url(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '', PHP_URL_PATH);
    $home = (string) parse_url(home_url('/'), PHP_URL_PATH);
    if ($home !== '' && $home !== '/' && strpos($path, $home) === 0) $path = substr($path, strlen($home));
    if (trim($path, '/') !== $s['slug']) return;

    $action = isset($_GET['kgs']) ? sanitize_key(wp_unslash($_GET['kgs'])) : '';

    switch ($action) {
        case '':
            // The page itself holds no map data — it is the same for everyone, logged in or not.
            kgs_no_cache();
            status_header(200);
            include __DIR__ . '/templates/viewer.php';
            exit;

        case 'login':
            if ((isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : '') !== 'POST') kgs_json(array('ok' => false, 'error' => 'POST required'), 405);
            if (kgs_is_locked()) kgs_json(array('ok' => false, 'error' => 'Too many wrong passwords. Wait ' . KGS_LOCK_MINUTES . ' minutes and try again.'), 429);
            $body = json_decode((string) file_get_contents('php://input'), true);
            $pass = is_array($body) && isset($body['password']) ? trim((string) $body['password']) : '';   // spaces before/after are ignored
            $person = $pass !== '' ? kgs_find_person_by_password($pass) : null;
            if (!$person) {
                kgs_note_fail();
                if ($pass !== '') kgs_log_add('fail');
                usleep(400000);
                kgs_json(array('ok' => false, 'error' => 'That password was not recognised.'), 401);
            }
            kgs_clear_fails();
            $exp = time() + max(1, (int) $s['days']) * DAY_IN_SECONDS;
            kgs_set_cookie($person['id'] . '.' . $exp . '.' . kgs_sign($person['id'], $exp, $person['hash']), $exp);
            // remember when this person last opened the map (shown to the admin only)
            $people = kgs_people();
            foreach ($people as &$p) {
                if ((string) $p['id'] === (string) $person['id']) { $p['last_login'] = time(); $p['last_seen'] = time(); $p['logins'] = (int) (isset($p['logins']) ? $p['logins'] : 0) + 1; }
            }
            unset($p);
            update_option(KGS_OPTION_PEOPLE, $people, false);
            kgs_log_add('login', $person);
            kgs_json(array('ok' => true));

        case 'logout':
            kgs_set_cookie('', time() - DAY_IN_SECONDS);
            kgs_no_cache();
            wp_safe_redirect(kgs_viewer_url());
            exit;

        case 'data':
            $viewer = kgs_current_person();
            if (!$viewer && !empty($s['require_password'])) kgs_json(array('ok' => false, 'error' => 'login'), 401);
            if ($viewer) kgs_log_open($viewer);          // visitors without a login are not listed in Activity
            kgs_places_schedule($s);
            $payload = kgs_build_payload($s);
            $payload['open'] = empty($s['require_password']);   // true = no password needed
            $payload['signed_in'] = (bool) $viewer;
            kgs_json($payload);

        case 'photo':
            if (!empty($s['require_password']) && !kgs_current_person()) { kgs_no_cache(); status_header(401); exit; }
            kgs_send_photo($s, isset($_GET['f']) ? (string) wp_unslash($_GET['f']) : '');
            exit;

        default:
            kgs_json(array('ok' => false, 'error' => 'Unknown action'), 404);
    }
}

/* ============================================================
 * ACTIVATION
 * ============================================================ */
register_activation_hook(__FILE__, function () {
    if (get_option(KGS_OPTION_SETTINGS, null) === null) add_option(KGS_OPTION_SETTINGS, kgs_defaults(), '', false);
    if (get_option(KGS_OPTION_PEOPLE, null) === null) add_option(KGS_OPTION_PEOPLE, array(), '', false);
    if (get_option(KGS_OPTION_LOG, null) === null) add_option(KGS_OPTION_LOG, array(), '', false);
});
