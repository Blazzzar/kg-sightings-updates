<?php
/**
 * Settings → KG Sightings: the list of people and their passwords,
 * and what viewers are allowed to see.
 */

if (!defined('ABSPATH')) exit;

add_action('admin_menu', function () {
    add_options_page('KG Sightings', 'KG Sightings', 'manage_options', 'kg-sightings', 'kgs_render_admin');
});

add_filter('plugin_action_links_' . plugin_basename(KGS_PLUGIN_FILE), function ($links) {
    array_unshift($links, '<a href="' . esc_url(admin_url('options-general.php?page=kg-sightings')) . '">People &amp; settings</a>');
    return $links;
});

/** Handle the forms on the settings page. Returns array(type, message) or null. */
function kgs_admin_handle_post() {
    if (empty($_POST['kgs_action'])) return null;
    if (!current_user_can('manage_options')) return array('error', 'You are not allowed to change these settings.');
    check_admin_referer('kgs_admin');

    $action = sanitize_key(wp_unslash($_POST['kgs_action']));
    $people = kgs_people();

    if ($action === 'add' || $action === 'reset') {
        $pass = isset($_POST['kgs_password']) ? trim((string) wp_unslash($_POST['kgs_password'])) : '';
        if (strlen($pass) < 6) return array('error', 'The password needs at least 6 characters.');
        $hash = kgs_hash_password($pass);
        $id   = $action === 'reset' ? sanitize_key(wp_unslash(isset($_POST['kgs_id']) ? $_POST['kgs_id'] : '')) : '';
        foreach ($people as $p) {
            if (hash_equals((string) $p['hash'], $hash) && (string) $p['id'] !== $id) {
                return array('error', 'Someone else already has that password. Each person needs a different one, because the password is what tells the map who is logging in.');
            }
        }
        if ($action === 'add') {
            $name = sanitize_text_field(wp_unslash(isset($_POST['kgs_name']) ? $_POST['kgs_name'] : ''));
            if ($name === '') return array('error', 'Type a name so you can tell the passwords apart later.');
            $people[] = array('id' => substr(md5(uniqid('', true)), 0, 10), 'name' => $name, 'hash' => $hash, 'enc' => kgs_encrypt_password($pass), 'created' => time(), 'last_login' => 0, 'logins' => 0);
            update_option(KGS_OPTION_PEOPLE, $people, false);
            return array('success', sprintf('%s was added. Their password is: %s — you can see it again any time with the Show button in their row.', esc_html($name), '<code>' . esc_html($pass) . '</code>'));
        }
        foreach ($people as &$p) {
            if ((string) $p['id'] === $id) {
                $p['hash'] = $hash;
                $p['enc']  = kgs_encrypt_password($pass);
                $name = $p['name'];
                unset($p);
                update_option(KGS_OPTION_PEOPLE, $people, false);
                return array('success', sprintf('New password for %s: %s. Their old password, and any browser still logged in with it, stopped working.', esc_html($name), '<code>' . esc_html($pass) . '</code>'));
            }
        }
        unset($p);
        return array('error', 'That person was not found.');
    }

    if ($action === 'remove') {
        $id = sanitize_key(wp_unslash(isset($_POST['kgs_id']) ? $_POST['kgs_id'] : ''));
        $name = '';
        foreach ($people as $i => $p) {
            if ((string) $p['id'] === $id) { $name = $p['name']; unset($people[$i]); }
        }
        if ($name === '') return array('error', 'That person was not found.');
        update_option(KGS_OPTION_PEOPLE, array_values($people), false);
        return array('success', sprintf('%s was removed. Their password no longer works, and any browser they were logged in on is logged out.', esc_html($name)));
    }

    if ($action === 'reset_logins') {
        $id = sanitize_key(wp_unslash(isset($_POST['kgs_id']) ? $_POST['kgs_id'] : ''));
        $name = '';
        foreach ($people as &$p) {
            if ((string) $p['id'] === $id) { $name = $p['name']; $p['logins'] = 0; $p['last_login'] = 0; $p['last_seen'] = 0; }
        }
        unset($p);
        if ($name === '') return array('error', 'That person was not found.');
        update_option(KGS_OPTION_PEOPLE, $people, false);
        $log = array_values(array_filter(kgs_log_entries(), function ($r) use ($id) { return $r['id'] !== $id; }));
        update_option(KGS_OPTION_LOG, $log, false);
        return array('success', sprintf('Logins for %s were reset to 0 and their rows were removed from the Activity list. Their password still works and they stay logged in.', esc_html($name)));
    }

    if ($action === 'fill_places') {
        if (function_exists('set_time_limit')) @set_time_limit(60);
        $found = kgs_places_fill(15);
        $left  = count(kgs_places_pending(kgs_settings()));
        return array('success', sprintf('Looked up %d pin%s. %s', $found, $found === 1 ? '' : 's', $left ? $left . ' still to do — click the button again, or leave it and they are done in the background.' : 'Every pin now has its town and state.'));
    }

    if ($action === 'clear_log') {
        update_option(KGS_OPTION_LOG, array(), false);
        return array('success', 'The activity log was emptied.');
    }

    if ($action === 'settings') {
        $s = kgs_settings();
        $slug = sanitize_title(wp_unslash(isset($_POST['kgs_slug']) ? $_POST['kgs_slug'] : ''));
        $s['slug']         = $slug !== '' ? $slug : 'sightings';
        $s['map_dir']      = trim(sanitize_text_field(wp_unslash(isset($_POST['kgs_map_dir']) ? $_POST['kgs_map_dir'] : 'map')), '/ ');
        foreach (array('show_planned', 'show_gone', 'show_address', 'show_notes', 'show_date', 'show_town') as $k) $s[$k] = empty($_POST['kgs_' . $k]) ? 0 : 1;
        $s['require_password'] = (isset($_POST['kgs_require_password']) && (string) wp_unslash($_POST['kgs_require_password']) === '0') ? 0 : 1;
        $s['days']         = max(1, min(365, (int) (isset($_POST['kgs_days']) ? $_POST['kgs_days'] : 30)));
        update_option(KGS_OPTION_SETTINGS, $s, false);
        return array('success', 'Settings saved.');
    }
    return null;
}

function kgs_render_admin() {
    if (!current_user_can('manage_options')) return;
    $notice = kgs_admin_handle_post();
    $s      = kgs_settings();
    $people = kgs_people();
    $dir    = kgs_map_dir($s);
    $shown  = count(kgs_visible_placements($s));
    $url    = kgs_viewer_url();
    $fmt    = get_option('date_format') . ' ' . get_option('time_format');
    ?>
    <div class="wrap">
      <h1>KG Sightings <span style="font-size:12px;color:#777;">v<?php echo esc_html(KGS_VERSION); ?></span></h1>
      <?php if ($notice): ?>
        <div class="notice notice-<?php echo esc_attr($notice[0]); ?>"><p><?php echo wp_kses($notice[1], array('code' => array())); ?></p></div>
      <?php endif; ?>

      <p style="max-width:820px;">The view-only map is at <a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener"><code><?php echo esc_html($url); ?></code></a>.
        It shows the same pins as the private map but has no way to add, change or delete anything. <?php echo !empty($s['require_password']) ? 'Send a person that address and their own password — there is no username.' : ''; ?></p>
      <?php if (empty($s['require_password'])): ?>
        <div class="notice notice-warning inline"><p><strong>The map is open to anyone with the address — no password is asked for.</strong> Change this under “What viewers see” → “Who can open the map”.</p></div>
      <?php endif; ?>

      <?php if ($dir === ''): ?>
        <div class="notice notice-error inline"><p><strong>The private map folder was not found.</strong> This plugin looked for <code><?php echo esc_html(rtrim(ABSPATH, '/') . '/' . $s['map_dir']); ?></code>. Correct the folder name under “What viewers see” below.</p></div>
      <?php else: ?>
        <p style="color:#555;">Right now a viewer sees <strong><?php echo (int) $shown; ?></strong> pin<?php echo $shown === 1 ? '' : 's'; ?>.</p>
      <?php endif; ?>

      <h2>People</h2>
      <table class="widefat striped" style="max-width:980px;">
        <thead><tr><th>Name</th><th style="width:250px;">Password</th><th>Added</th><th>Last opened the map</th><th>Logins</th><th style="width:400px;">Actions</th></tr></thead>
        <tbody>
        <?php if (!$people): ?>
          <tr><td colspan="6">Nobody yet. Add the first person below.</td></tr>
        <?php endif; ?>
        <?php foreach ($people as $p): ?>
          <tr>
            <td><strong><?php echo esc_html($p['name']); ?></strong></td>
            <td>
              <?php $kgs_plain = kgs_decrypt_password(isset($p['enc']) ? $p['enc'] : ''); ?>
              <?php if ($kgs_plain !== null): ?>
                <code class="kgs-pw" data-pw="<?php echo esc_attr($kgs_plain); ?>">••••••••</code>
                <button type="button" class="button button-small kgs-show">Show</button>
                <button type="button" class="button button-small kgs-copy">Copy</button>
              <?php else: ?>
                <span style="color:#999;" title="This password was set before passwords could be shown. Set a new one to make it viewable.">not viewable — set a new one</span>
              <?php endif; ?>
            </td>
            <td><?php echo esc_html(wp_date(get_option('date_format'), (int) $p['created'])); ?></td>
            <?php $kgs_seen = max((int) (isset($p['last_seen']) ? $p['last_seen'] : 0), (int) (isset($p['last_login']) ? $p['last_login'] : 0)); ?>
            <td><?php echo $kgs_seen ? esc_html(wp_date($fmt, $kgs_seen)) : '<span style="color:#999;">never</span>'; ?></td>
            <td style="white-space:nowrap;">
              <?php echo (int) (isset($p['logins']) ? $p['logins'] : 0); ?>
              <form method="post" style="display:inline;" onsubmit="return confirm('Reset the login count for <?php echo esc_js($p['name']); ?> and remove their rows from the Activity list?');">
                <?php wp_nonce_field('kgs_admin'); ?>
                <input type="hidden" name="kgs_action" value="reset_logins">
                <input type="hidden" name="kgs_id" value="<?php echo esc_attr($p['id']); ?>">
                <button class="button button-small" style="margin-left:6px;" title="Set this count back to 0, clear “last opened”, and remove this person’s rows from the Activity list">Reset</button>
              </form>
            </td>
            <td>
              <form method="post" style="display:inline-flex;gap:6px;align-items:center;">
                <?php wp_nonce_field('kgs_admin'); ?>
                <input type="hidden" name="kgs_action" value="reset">
                <input type="hidden" name="kgs_id" value="<?php echo esc_attr($p['id']); ?>">
                <input type="text" name="kgs_password" placeholder="new password" autocomplete="off" style="width:170px;">
                <button class="button">Set new password</button>
              </form>
              <form method="post" style="display:inline;" onsubmit="return confirm('Remove <?php echo esc_js($p['name']); ?>? Their password stops working straight away.');">
                <?php wp_nonce_field('kgs_admin'); ?>
                <input type="hidden" name="kgs_action" value="remove">
                <input type="hidden" name="kgs_id" value="<?php echo esc_attr($p['id']); ?>">
                <button class="button button-link-delete" style="margin-left:8px;">Remove</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>

      <h3 style="margin-top:22px;">Add a person</h3>
      <form method="post" style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap;max-width:980px;">
        <?php wp_nonce_field('kgs_admin'); ?>
        <input type="hidden" name="kgs_action" value="add">
        <label>Name (only you see this)<br><input type="text" name="kgs_name" class="regular-text" placeholder="Tim G" autocomplete="off" required></label>
        <label>Password (this is what they type)<br><input type="text" name="kgs_password" id="kgs-new-pass" class="regular-text" autocomplete="off" required minlength="6"></label>
        <button type="button" class="button" id="kgs-gen">Suggest one</button>
        <button class="button button-primary">Add person</button>
      </form>
      <p class="description" style="max-width:820px;">Each person needs a different password of at least 6 characters. The name is never shown to them and is not used to log in. Passwords are case-sensitive; spaces before or after are ignored.</p>
      <script>
      document.querySelectorAll('.kgs-show').forEach(function (b) {
        b.addEventListener('click', function () {
          var c = b.parentNode.querySelector('.kgs-pw'), shown = b.textContent === 'Hide';
          c.textContent = shown ? '••••••••' : c.getAttribute('data-pw');
          b.textContent = shown ? 'Show' : 'Hide';
        });
      });
      document.querySelectorAll('.kgs-copy').forEach(function (b) {
        b.addEventListener('click', function () {
          var pw = b.parentNode.querySelector('.kgs-pw').getAttribute('data-pw');
          navigator.clipboard.writeText(pw).then(function () { b.textContent = 'Copied'; setTimeout(function () { b.textContent = 'Copy'; }, 1500); });
        });
      });
      document.getElementById('kgs-gen').addEventListener('click', function () {
        var words = ['mori','ghost','knock','drip','lace','tulip','bone','ember','hush','moth','vellum','candle','shade','wisp','hour','glass'];
        var pick = function () { var a = new Uint32Array(1); crypto.getRandomValues(a); return a[0]; };
        document.getElementById('kgs-new-pass').value = words[pick() % words.length] + '-' + words[pick() % words.length] + '-' + (100 + pick() % 900);
      });
      </script>

      <h2 style="margin-top:34px;">Activity</h2>
      <?php
        $kgs_log    = kgs_log_entries();
        $kgs_who    = isset($_GET['kgs_who']) ? sanitize_key(wp_unslash($_GET['kgs_who'])) : '';
        $kgs_all    = !empty($_GET['kgs_all']);
        $kgs_rows   = $kgs_who !== '' ? array_values(array_filter($kgs_log, function ($r) use ($kgs_who) { return $r['id'] === $kgs_who; })) : $kgs_log;
        $kgs_total  = count($kgs_rows);
        if (!$kgs_all) $kgs_rows = array_slice($kgs_rows, 0, 50);
        $kgs_labels = array('login' => 'Logged in', 'open' => 'Opened the map', 'fail' => 'Wrong password');
        $kgs_page   = admin_url('options-general.php?page=kg-sightings');
      ?>
      <p style="max-width:820px;">Newest first. “Logged in” is a password being typed. “Opened the map” is someone who was already logged in loading the map; opens by the same person on the same device within 30 minutes count once. The last <?php echo (int) KGS_LOG_MAX; ?> entries are kept.</p>
      <form method="get" action="<?php echo esc_url(admin_url('options-general.php')); ?>" style="margin:8px 0;">
        <input type="hidden" name="page" value="kg-sightings">
        <label>Show
          <select name="kgs_who" onchange="this.form.submit()">
            <option value="">everyone</option>
            <?php foreach ($people as $p): ?>
              <option value="<?php echo esc_attr($p['id']); ?>" <?php echo $kgs_who === (string) $p['id'] ? 'selected' : ''; ?>><?php echo esc_html($p['name']); ?></option>
            <?php endforeach; ?>
          </select>
        </label>
      </form>
      <table class="widefat striped" style="max-width:980px;">
        <thead><tr><th style="width:230px;">When</th><th>Who</th><th>What</th><th>Device</th></tr></thead>
        <tbody>
        <?php if (!$kgs_rows): ?>
          <tr><td colspan="4">Nothing yet.</td></tr>
        <?php endif; ?>
        <?php foreach ($kgs_rows as $r): ?>
          <tr>
            <td><?php echo esc_html(wp_date($fmt, (int) $r['t'])); ?></td>
            <td><?php echo $r['n'] !== '' ? '<strong>' . esc_html($r['n']) . '</strong>' : '<span style="color:#999;">unknown</span>'; ?></td>
            <td<?php echo $r['e'] === 'fail' ? ' style="color:#b32d2e;"' : ''; ?>><?php echo esc_html(isset($kgs_labels[$r['e']]) ? $kgs_labels[$r['e']] : $r['e']); ?></td>
            <td><?php echo esc_html($r['d']); ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <p>
        <?php if (!$kgs_all && $kgs_total > 50): ?>
          Showing 50 of <?php echo (int) $kgs_total; ?>. <a href="<?php echo esc_url($kgs_page . '&kgs_all=1' . ($kgs_who !== '' ? '&kgs_who=' . $kgs_who : '')); ?>">Show all</a>
        <?php endif; ?>
      </p>
      <?php if ($kgs_log): ?>
      <form method="post" onsubmit="return confirm('Empty the activity log? This cannot be undone.');">
        <?php wp_nonce_field('kgs_admin'); ?>
        <input type="hidden" name="kgs_action" value="clear_log">
        <button class="button">Empty the log</button>
      </form>
      <?php endif; ?>

      <h2 style="margin-top:34px;">What viewers see</h2>
      <form method="post">
        <?php wp_nonce_field('kgs_admin'); ?>
        <input type="hidden" name="kgs_action" value="settings">
        <table class="form-table" role="presentation" style="max-width:980px;">
          <tr><th scope="row">Who can open the map</th><td>
            <label><input type="radio" name="kgs_require_password" value="1" <?php checked(!empty($s['require_password'])); ?>> Only people with a password <span class="description">(the People list above)</span></label><br>
            <label><input type="radio" name="kgs_require_password" value="0" <?php checked(empty($s['require_password'])); ?>> Anyone with the address — no password</label>
            <p class="description">With no password, anyone who has or finds the address sees every pin and photo allowed by the switches below. The People list is kept, so you can switch back at any time. Visitors without a login do not appear in the Activity list.</p>
          </td></tr>
          <tr><th scope="row">Pins</th><td>
            <p>Placed pieces are always shown.</p>
            <label><input type="checkbox" name="kgs_show_planned" value="1" <?php checked($s['show_planned']); ?>> Also show planned spots (X pins)</label><br>
            <label><input type="checkbox" name="kgs_show_gone" value="1" <?php checked($s['show_gone']); ?>> Also show pieces marked “gone”</label>
          </td></tr>
          <tr><th scope="row">Details on each pin</th><td>
            <p>Title, piece type and photos are always shown.</p>
            <label><input type="checkbox" name="kgs_show_town" value="1" <?php checked($s['show_town']); ?>> Show the town and state (for example “Chicago, IL”)</label><br>
            <label><input type="checkbox" name="kgs_show_date" value="1" <?php checked($s['show_date']); ?>> Show the date and time each piece was placed</label><br>
            <label><input type="checkbox" name="kgs_show_address" value="1" <?php checked($s['show_address']); ?>> Show the written address</label><br>
            <label><input type="checkbox" name="kgs_show_notes" value="1" <?php checked($s['show_notes']); ?>> Show your notes</label>
            <p class="description">The pin itself still sits at its real position on the map, whether or not the written address is shown.</p>
          </td></tr>
          <tr><th scope="row"><label for="kgs_days">A login lasts</label></th><td>
            <input type="number" id="kgs_days" name="kgs_days" min="1" max="365" value="<?php echo (int) $s['days']; ?>" style="width:80px;"> days on one browser, then the password is asked for again.
          </td></tr>
          <tr><th scope="row"><label for="kgs_slug">Address</label></th><td>
            <code><?php echo esc_html(home_url('/')); ?></code><input type="text" id="kgs_slug" name="kgs_slug" value="<?php echo esc_attr($s['slug']); ?>" style="width:160px;"><code>/</code>
            <p class="description">Changing this changes the link you have already sent to people.</p>
          </td></tr>
          <tr><th scope="row"><label for="kgs_map_dir">Private map folder</label></th><td>
            <code><?php echo esc_html(rtrim(ABSPATH, '/')); ?>/</code><input type="text" id="kgs_map_dir" name="kgs_map_dir" value="<?php echo esc_attr($s['map_dir']); ?>" style="width:160px;">
            <?php echo $dir !== '' ? '<span style="color:#1f7a3a;">found</span>' : '<span style="color:#b32d2e;">not found</span>'; ?>
          </td></tr>
        </table>
        <?php submit_button('Save settings'); ?>
      </form>

      <h2>Town and state</h2>
      <?php $kgs_pending = count(kgs_places_pending($s)); kgs_places_schedule($s); ?>
      <p style="max-width:820px;">Each pin's town and state is worked out from its position on the map by OpenStreetMap's lookup service, once, and then remembered. New pins are looked up in the background within a few minutes of someone opening the map or this page.
        <?php echo $kgs_pending ? '<strong>' . (int) $kgs_pending . ' pin' . ($kgs_pending === 1 ? '' : 's') . ' still to look up.</strong>' : 'Every pin has been looked up.'; ?></p>
      <?php if ($kgs_pending): ?>
      <form method="post">
        <?php wp_nonce_field('kgs_admin'); ?>
        <input type="hidden" name="kgs_action" value="fill_places">
        <button class="button">Look up now (up to 15 pins, takes about 20 seconds)</button>
      </form>
      <?php endif; ?>

      <h2 style="margin-top:34px;">One-time server setting</h2>
      <p style="max-width:820px;">In SiteGround Site Tools → Speed → Caching → Dynamic Cache → Exclude URLs, add <code>/<?php echo esc_html($s['slug']); ?>/*</code>. The page already asks not to be stored, and this makes sure of it.</p>
    </div>
    <?php
}
