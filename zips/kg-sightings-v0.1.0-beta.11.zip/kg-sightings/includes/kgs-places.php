<?php
/**
 * Town and state for each pin, shown to viewers instead of a street address.
 *
 * Worked out from the pin's position by OpenStreetMap's lookup service
 * (Nominatim), once per pin, and kept in the site database (option
 * kgs_places). Lookups run in the background, one per second at most,
 * which is that service's limit. The private map's files are not touched.
 */

if (!defined('ABSPATH')) exit;

define('KGS_OPTION_PLACES', 'kgs_places');   // pin id => array(k: "lat,lng", town, state, t: time, ok: 0|1)
define('KGS_PLACES_BATCH', 20);              // lookups per background run
define('KGS_PLACES_RETRY', DAY_IN_SECONDS);  // wait before retrying a failed lookup

function kgs_places() {
    $p = get_option(KGS_OPTION_PLACES, array());
    return is_array($p) ? $p : array();
}

function kgs_place_key($lat, $lng) { return round((float) $lat, 4) . ',' . round((float) $lng, 4); }

/** "Chicago, IL" for a pin, or '' when it is not known yet. */
function kgs_place_label($places, $id, $lat, $lng) {
    if (!isset($places[$id]) || empty($places[$id]['ok']) || $places[$id]['k'] !== kgs_place_key($lat, $lng)) return '';
    $town = (string) $places[$id]['town']; $state = (string) $places[$id]['state'];
    return $town !== '' && $state !== '' ? $town . ', ' . $state : ($town !== '' ? $town : $state);
}

/** Ask OpenStreetMap which town and state a position is in. Returns array(town, state) or null. */
function kgs_lookup_place($lat, $lng) {
    $url = 'https://nominatim.openstreetmap.org/reverse?format=jsonv2&addressdetails=1&zoom=12&accept-language=en&lat=' . rawurlencode((string) $lat) . '&lon=' . rawurlencode((string) $lng);
    $res = wp_remote_get($url, array('timeout' => 8, 'user-agent' => 'KG-Sightings/' . KGS_VERSION . ' (' . home_url('/') . ')'));
    if (is_wp_error($res) || (int) wp_remote_retrieve_response_code($res) !== 200) return null;
    $j = json_decode((string) wp_remote_retrieve_body($res), true);
    if (!is_array($j) || empty($j['address']) || !is_array($j['address'])) return null;
    $a = $j['address'];
    $town = '';
    foreach (array('city', 'town', 'village', 'municipality', 'hamlet', 'suburb', 'county') as $k) {
        if (!empty($a[$k])) { $town = (string) $a[$k]; break; }
    }
    $state = '';
    $cc = isset($a['country_code']) ? strtolower((string) $a['country_code']) : '';
    if ($cc === 'us' && !empty($a['ISO3166-2-lvl4']) && preg_match('/^US-([A-Z]{2})$/', (string) $a['ISO3166-2-lvl4'], $m)) $state = $m[1];   // "IL"
    elseif (!empty($a['state'])) $state = (string) $a['state'];
    elseif (!empty($a['country'])) $state = (string) $a['country'];
    if ($town === '' && $state === '') return null;
    return array($town, $state);
}

/** Pins (from the private map's file) that still need a lookup. */
function kgs_places_pending($s) {
    $dir = kgs_map_dir($s);
    if ($dir === '' || !is_file($dir . '/data/placements.json')) return array();
    $doc = json_decode((string) file_get_contents($dir . '/data/placements.json'), true);
    $places = kgs_places(); $todo = array();
    foreach ((array) (isset($doc['placements']) ? $doc['placements'] : array()) as $p) {
        if (!is_array($p) || empty($p['id']) || !isset($p['lat'], $p['lng'])) continue;
        $id = (string) $p['id']; $k = kgs_place_key($p['lat'], $p['lng']);
        $have = isset($places[$id]) && $places[$id]['k'] === $k;
        if ($have && !empty($places[$id]['ok'])) continue;
        if ($have && empty($places[$id]['ok']) && (int) $places[$id]['t'] > time() - KGS_PLACES_RETRY) continue;
        $todo[] = array('id' => $id, 'lat' => (float) $p['lat'], 'lng' => (float) $p['lng'], 'k' => $k);
    }
    return $todo;
}

/** Look up to $max pending pins, one per second. Returns how many were found. */
function kgs_places_fill($max = KGS_PLACES_BATCH) {
    $s = kgs_settings();
    $todo = array_slice(kgs_places_pending($s), 0, $max);
    if (!$todo) return 0;
    $places = kgs_places(); $found = 0;
    foreach ($todo as $i => $p) {
        if ($i > 0 && !defined('KGS_TEST_NO_SLEEP')) usleep(1100000);
        $r = kgs_lookup_place($p['lat'], $p['lng']);
        $places[$p['id']] = array('k' => $p['k'], 'town' => $r ? $r[0] : '', 'state' => $r ? $r[1] : '', 't' => time(), 'ok' => $r ? 1 : 0);
        if ($r) $found++;
    }
    update_option(KGS_OPTION_PLACES, $places, false);
    return $found;
}

/** Queue a background run when pins are waiting. Called when the map or the settings page is opened. */
function kgs_places_schedule($s) {
    if (empty($s['show_town'])) return;
    if (wp_next_scheduled('kgs_fill_places')) return;
    if (!kgs_places_pending($s)) return;
    wp_schedule_single_event(time() + 5, 'kgs_fill_places');
}
add_action('kgs_fill_places', function () { kgs_places_fill(KGS_PLACES_BATCH); });
