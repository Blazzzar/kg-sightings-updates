/* KG Sightings — view-only map. Reads pins; has no way to change them. */
(() => {
'use strict';
const CFG = window.KGS;
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const call = (action, opts = {}) => fetch(`${CFG.base}?kgs=${action}`, Object.assign({ credentials: 'same-origin', cache: 'no-store' }, opts, { headers: Object.assign({ 'X-KG-Sightings': '1' }, opts.headers || {}) }));
const STATUS_LABEL = { placed: 'Placed', planned: 'Planned', gone: 'Gone' };

let placements = [], markers = new Map(), selectedId = null, query = '';
let OPEN = false;   // true when the map needs no password
let icons = { mori: '', x: '', types: {} };
let S = null, TINT = null, map = null, cluster = null;
const filters = { placed: true, planned: true, gone: true };

function toast(msg, ms = 2600) { const t = $('#toast'); t.textContent = msg; t.classList.add('on'); clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove('on'), ms); }

// ------------------------------------------------------------ login
function showGate(msg) { $('#gate').classList.add('on'); $('#gate-err').textContent = msg || ''; setTimeout(() => $('#gate-pass').focus(), 50); }
$('#gate-form').addEventListener('submit', async e => {
  e.preventDefault();
  const pw = $('#gate-pass').value; if (!pw) return;
  const btn = $('#gate-form button'); btn.disabled = true; $('#gate-err').textContent = '';
  try {
    const r = await call('login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password: pw }) });
    const j = await r.json().catch(() => ({}));
    if (r.ok && j.ok) { $('#gate-pass').value = ''; await boot(); }
    else $('#gate-err').textContent = j.error || 'Could not log in. Try again.';
  } catch { $('#gate-err').textContent = 'No connection. Try again.'; }
  btn.disabled = false;
});

async function boot() {
  let r; try { r = await call('data'); } catch { return showGate('No connection. Reload the page.'); }
  if (r.status === 401) return showGate('');
  const d = await r.json().catch(() => null);
  if (!d || !d.ok) return showGate('The map could not be loaded.');
  $('#gate').classList.remove('on');
  OPEN = !!d.open;
  $('#logout').hidden = !d.signed_in;
  start(d);
}

// ------------------------------------------------------------ look (tint, pins, panel colours)
const TINTS = {
  paper: { ink: '#14231b', paper: '#d6e6cc', glow: 0 }, ink: { ink: '#0f4a2c', paper: '#f1efe2', glow: 0 },
  phosphor: { ink: '#8ff489', paper: '#081a0d', glow: 0 }, forest: { ink: '#b7d2b3', paper: '#1b2b21', glow: 0 },
  acid: { ink: '#d4ff2a', paper: '#0b1206', glow: 1.6 }, slime: { ink: '#3dff5c', paper: '#02100a', glow: 2.4 },
  ecto: { ink: '#b4ff3c', paper: '#120a24', glow: 1.6 }, pink: { ink: '#ff6ad5', paper: '#07160c', glow: 1.6 },
  toxic: { ink: '#e4ff00', paper: '#000000', glow: 0 }
};
const hexOk = v => /^#[0-9a-f]{6}$/i.test(String(v || ''));
const hex2rgb = h => { h = String(h).replace('#', ''); return [0, 2, 4].map(i => parseInt(h.slice(i, i + 2), 16)); };
function resolveLook(look, config) {
  const t = TINTS[String(config.tint || '').toLowerCase()];
  const base = {
    tint: { on: !!t, ink: t?.ink || '#8ff489', paper: t?.paper || '#081a0d', glow: +(t?.glow || 0), saturation: 1, brightness: 1 },
    pins: { moriHeight: 40, typeScale: 1, xSize: 33, xDark: '#eaf7e6', goneOpacity: .35, halo: 1 },
    ui: { paper: '#f5f3ee', ink: '#231f20', mute: '#7a766e', line: '#cfcbc2', font: 'sans' }
  };
  for (const g of ['tint', 'pins', 'ui']) Object.assign(base[g], look?.[g] || {});
  return base;
}
function buildTint(t) {
  if (!t || !t.on || !hexOk(t.ink) || !hexOk(t.paper)) return null;
  const i = hex2rgb(t.ink), p = hex2rgb(t.paper), sat = +t.saturation || 1, br = +t.brightness || 1;
  const lut = [0, 1, 2].map(() => new Uint8ClampedArray(256));
  for (let l = 0; l < 256; l++) {
    const c = [0, 1, 2].map(k => i[k] + (p[k] - i[k]) * l / 255);
    const g = c[0] * .2126 + c[1] * .7152 + c[2] * .0722;
    for (let k = 0; k < 3; k++) lut[k][l] = (g + (c[k] - g) * sat) * br;
  }
  return { lut, glow: Math.max(0, Math.min(3, +t.glow || 0)), paper: t.paper, dark: (p[0] * .2126 + p[1] * .7152 + p[2] * .0722) < 128 };
}
function paintTinted(canvas, img, bw) {
  const w = img.naturalWidth || img.width, h = img.naturalHeight || img.height;
  canvas.width = w; canvas.height = h;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  ctx.drawImage(img, 0, 0);
  if (!TINT && !bw) return;
  let id; try { id = ctx.getImageData(0, 0, w, h); } catch { return; }
  const d = id.data;
  if (TINT) { const R = TINT.lut[0], G = TINT.lut[1], B = TINT.lut[2];
    for (let k = 0; k < d.length; k += 4) { const l = (d[k] * 54 + d[k + 1] * 183 + d[k + 2] * 19) >> 8; d[k] = R[l]; d[k + 1] = G[l]; d[k + 2] = B[l]; }
  } else {
    for (let k = 0; k < d.length; k += 4) { const l = Math.min(255, ((d[k] * 54 + d[k + 1] * 183 + d[k + 2] * 19) >> 8) * 1.12 - 14); d[k] = d[k + 1] = d[k + 2] = l; }
  }
  ctx.putImageData(id, 0, 0);
  if (TINT && TINT.glow) {
    const f = Math.round(TINT.glow * 3) + 1, small = document.createElement('canvas');
    small.width = Math.max(1, Math.round(w / f)); small.height = Math.max(1, Math.round(h / f));
    small.getContext('2d').drawImage(canvas, 0, 0, small.width, small.height);
    ctx.globalCompositeOperation = 'screen'; ctx.drawImage(small, 0, 0, w, h); ctx.globalCompositeOperation = 'source-over';
  }
}
const TintedTiles = L.TileLayer.extend({
  createTile(coords, done) {
    const tile = document.createElement('canvas'), size = this.getTileSize();
    tile.width = size.x; tile.height = size.y;
    const img = new Image(); img.crossOrigin = 'anonymous';
    img.onload = () => { paintTinted(tile, img, this.options.bw); done(null, tile); };
    img.onerror = e => done(e, tile);
    img.src = this.getTileUrl(coords);
    return tile;
  }
});
function applyLook() {
  const root = document.documentElement.style, u = S.ui;
  TINT = buildTint(S.tint);
  document.body.classList.toggle('tint-dark', !!(TINT && TINT.dark));
  root.setProperty('--x-dark', S.pins.xDark);
  root.setProperty('--gone-opacity', String(S.pins.goneOpacity));
  root.setProperty('--halo', String(S.pins.halo));
  $('#map').style.background = TINT ? TINT.paper : '#e9e7e1';
  const ok = c => hexOk(c);
  if (ok(u.paper) && ok(u.ink)) {
    const mix = (a, b, t) => '#' + hex2rgb(a).map((v, i) => Math.round(v + (hex2rgb(b)[i] - v) * t).toString(16).padStart(2, '0')).join('');
    root.setProperty('--paper', u.paper); root.setProperty('--ink', u.ink); root.setProperty('--accent', u.ink);
    root.setProperty('--paper-2', mix(u.paper, u.ink, .06));
  }
  if (ok(u.mute)) root.setProperty('--mute', u.mute);
  if (ok(u.line)) root.setProperty('--line', u.line);
  if (u.font === 'mono') root.setProperty('--sans', 'ui-monospace, "SF Mono", Menlo, Consolas, "Courier New", monospace');
}

// ------------------------------------------------------------ icons
const fixSvg = txt => {
  txt = String(txt || '').replace(/<\?xml[^>]*>/, '').replace(/<svg([^>]*)\sid="[^"]*"/, '<svg$1');
  const fills = {}; const st = txt.match(/<style[^>]*>([\s\S]*?)<\/style>/);
  if (st) {
    for (const m of st[1].matchAll(/\.([\w-]+)\s*\{[^}]*?fill:\s*([^;}]+)/g)) fills[m[1]] = m[2].trim();
    txt = txt.replace(/<defs>\s*<style[\s\S]*?<\/style>\s*<\/defs>/, '').replace(/<style[\s\S]*?<\/style>/, '');
  }
  return txt.replace(/class="([\w-]+)"/g, (a, c) => fills[c] ? `fill="${fills[c]}"` : a).trim();
};
const typeIcon = p => icons.types[(p.type || '').trim().toLowerCase()] || null;
function makeIcon(p, selected = false) {
  const H = +S.pins.moriHeight || 40, W = Math.round(H * 167.4 / 258.43), X = +S.pins.xSize || 33, TS = +S.pins.typeScale || 1;
  const isX = p.status === 'planned', ti = isX ? null : typeIcon(p);
  const size = isX ? [X, X] : ti ? [Math.round(ti.size * TS), Math.round(ti.size * TS)] : [W, H];
  return L.divIcon({ html: isX ? icons.x : ti ? ti.svg : icons.mori, className: `kg-marker ${p.status}${selected ? ' selected' : ''}`, iconSize: size, iconAnchor: [size[0] / 2, size[1] / 2], popupAnchor: [0, -size[1] / 2 - 4] });
}

// ------------------------------------------------------------ helpers
function parseDate(s) { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s); return m ? new Date(+m[1], +m[2] - 1, +m[3]) : new Date(s); }
function fmtDate(s, withTime = true) {
  if (!s) return '';
  const d = parseDate(s); if (isNaN(d)) return s;
  let out = d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
  if (withTime && s.includes('T')) out += ' · ' + d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
  return out;
}
const photoUrl = (ph, thumb = false) => `${CFG.base}?kgs=photo&f=${encodeURIComponent(thumb && ph.thumb ? ph.thumb : ph.file)}`;
const mq = window.matchMedia('(max-width: 760px)');
const isMobile = () => mq.matches;
const visible = p => filters[p.status] && (!query || [p.title, p.type, p.address, p.notes, p.placed_at].join(' ').toLowerCase().includes(query));
const metaHtml = p => `<b>${STATUS_LABEL[p.status]}</b>${p.type ? ' · ' + esc(p.type) : ''}${p.placed_at ? '<br>' + esc(fmtDate(p.placed_at)) : ''}${p.last_seen ? '<br>Last seen ' + esc(fmtDate(p.last_seen, false)) : ''}${p.address ? '<br>' + esc(p.address) : ''}`;

// ------------------------------------------------------------ start
function start(d) {
  placements = d.placements || [];
  icons = { mori: fixSvg(d.icons.mori), x: fixSvg(d.icons.x), types: {} };
  for (const [k, v] of Object.entries(d.icons.types || {})) icons.types[k] = { svg: fixSvg(v.svg), size: v.size || 40 };
  S = resolveLook(d.look, d.config || {});
  applyLook();

  if (!map) {
    map = L.map('map', { zoomControl: true }).setView(d.config.center || [41.9068, -87.678], d.config.zoom || 14);
    const OSM_ATTR = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';
    const STADIA_ATTR = '&copy; <a href="https://www.stadiamaps.com/">Stadia Maps</a> &copy; <a href="https://www.stamen.com/">Stamen Design</a> &copy; <a href="https://openmaptiles.org/">OpenMapTiles</a> ' + OSM_ATTR;
    const key = (d.config.stadia || '').trim(), want = d.config.basemap || 'toner';
    let layer;
    if (key && want.startsWith('toner')) layer = new TintedTiles(`https://tiles.stadiamaps.com/tiles/stamen_${want === 'toner-lite' ? 'toner_lite' : 'toner'}/{z}/{x}/{y}{r}.png?api_key=${encodeURIComponent(key)}`, { maxZoom: 20, attribution: STADIA_ATTR });
    else layer = new TintedTiles('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: OSM_ATTR, bw: want !== 'osm' });
    layer.addTo(map);
    cluster = L.markerClusterGroup({ maxClusterRadius: 44, showCoverageOnHover: false, spiderfyOnMaxZoom: true, disableClusteringAtZoom: 18,
      iconCreateFunction: c => L.divIcon({ html: `<div class="kg-cluster">${c.getChildCount()}</div>`, className: '', iconSize: [34, 34] }) });
    map.addLayer(cluster);
    map.on('popupopen', e => {
      e.popup.getElement().querySelector('[data-link]')?.addEventListener('click', ev => copyLink(ev.target.dataset.link));
    });
    map.on('click', () => { if (isMobile()) closeSheet(); });
  }

  // status chips only when more than one status is being shown
  const present = [...new Set(placements.map(p => p.status))];
  const fl = $('#filters');
  if (present.length > 1) {
    fl.hidden = false;
    fl.innerHTML = present.map(s => `<label class="chip" data-s="${s}"><span class="dot ${s}"></span>${STATUS_LABEL[s]} <span class="n">${placements.filter(p => p.status === s).length}</span></label>`).join('');
    $$('.chip', fl).forEach(ch => ch.addEventListener('click', () => { const s = ch.dataset.s; filters[s] = !filters[s]; ch.classList.toggle('off', !filters[s]); rebuild(); renderList(); }));
  } else fl.hidden = true;

  rebuild(); renderList();
  if (placements.length) map.fitBounds(L.latLngBounds(placements.map(p => [p.lat, p.lng])).pad(0.2), { maxZoom: 16 });
  const h = location.hash.slice(1);
  if (h && placements.find(p => p.id === h)) select(h, true);
}

function rebuild() {
  cluster.clearLayers(); markers.clear();
  placements.forEach(p => {
    if (!visible(p)) return;
    const m = L.marker([p.lat, p.lng], { icon: makeIcon(p, p.id === selectedId), title: p.title || STATUS_LABEL[p.status], riseOnHover: true });
    if (!isMobile()) m.bindPopup(() => popupHtml(p), { closeButton: true, autoPanPadding: [30, 30] });
    m.on('click', () => select(p.id, false));
    markers.set(p.id, m); cluster.addLayer(m);
  });
  const shown = placements.filter(visible).length;
  $('#count').textContent = shown === placements.length ? `${shown} sighting${shown === 1 ? '' : 's'}` : `${shown} of ${placements.length} shown`;
}
mq.addEventListener?.('change', () => { closeSheet(); if (cluster) rebuild(); });

function popupHtml(p) {
  const ph = p.photos?.[0], n = p.photos?.length || 0, MAX = 5;
  const strip = n > 1 ? `<div class="strip">${p.photos.slice(0, MAX).map((x, i) => `<img src="${photoUrl(x, true)}" data-gallery="${p.id}" data-index="${i}" alt="">`).join('')}${n > MAX ? `<div class="more" data-gallery="${p.id}" data-index="${MAX}">+${n - MAX}</div>` : ''}</div>` : '';
  return `<div class="pop">${ph ? `<img src="${photoUrl(ph, true)}" data-gallery="${p.id}" data-index="0" alt="">` : ''}${strip}
    <div class="body"><div class="t">${esc(p.title) || '<span style="color:var(--mute)">Untitled</span>'}</div>
    <div class="m">${metaHtml(p)}</div>${p.notes ? `<div class="notes">${esc(p.notes)}</div>` : ''}
    <div class="act"><button type="button" data-link="${p.id}">Copy link</button></div></div></div>`;
}
function copyLink(id) {
  const u = location.href.split('#')[0] + '#' + id;
  (navigator.clipboard?.writeText(u) || Promise.reject()).then(() => toast(OPEN ? 'Link copied' : 'Link copied — it still asks for a password')).catch(() => toast(u, 6000));
}

function renderList() {
  const list = $('#list');
  const rows = placements.filter(visible);   // the server sends them newest first
  if (!rows.length) { list.innerHTML = `<div class="empty-state">${placements.length ? 'Nothing matches.' : 'No sightings yet.'}</div>`; return; }
  list.innerHTML = rows.map(p => {
    const ph = p.photos?.[0];
    return `<div class="item${p.id === selectedId ? ' selected' : ''}" data-id="${p.id}">
      ${ph ? `<img class="thumb" src="${photoUrl(ph, true)}" alt="" loading="lazy">` : `<div class="thumb empty"></div>`}
      <div><div class="title"><span class="dot ${p.status}"></span>${esc(p.title) || '<span style="opacity:.6">Untitled</span>'}</div>
      <div class="meta">${p.type ? esc(p.type) : STATUS_LABEL[p.status]}${p.placed_at ? '<br>' + esc(fmtDate(p.placed_at)) : ''}${p.address ? '<br>' + esc(p.address) : ''}</div></div>
      <div class="ticon ${p.status}">${p.status === 'planned' ? icons.x : (typeIcon(p)?.svg || icons.mori)}</div></div>`;
  }).join('');
}
$('#list').addEventListener('click', e => { const it = e.target.closest('.item'); if (it) select(it.dataset.id, true); });
$('#q').addEventListener('input', e => { query = e.target.value.trim().toLowerCase(); rebuild(); renderList(); });

function select(id, fly) {
  const prev = selectedId; selectedId = id;
  const p = placements.find(x => x.id === id); if (!p) return;
  if (prev && markers.get(prev)) markers.get(prev).setIcon(makeIcon(placements.find(x => x.id === prev)));
  const m = markers.get(id);
  if (m) m.setIcon(makeIcon(p, true));
  history.replaceState(null, '', '#' + id);
  $$('#list .item').forEach(el => el.classList.toggle('selected', el.dataset.id === id));
  $(`#list .item[data-id="${id}"]`)?.scrollIntoView({ block: 'nearest' });
  if (isMobile()) { $('#panel').classList.remove('open'); setNav('map'); }
  if (!m) { if (isMobile()) openSheet(p); return; }
  const open = () => isMobile() ? openSheet(p) : m.openPopup();
  if (fly) { map.flyTo([p.lat, p.lng], Math.max(map.getZoom(), 17), { duration: .6 }); map.once('moveend', () => cluster.zoomToShowLayer(m, open)); }
  else cluster.zoomToShowLayer(m, open);
}

// ------------------------------------------------------------ phone layout
function setNav(which) { $$('#mnav button').forEach(b => b.classList.toggle('active', b.dataset.m === which)); }
function openSheet(p) {
  const ph = p.photos?.[0], n = p.photos?.length || 0;
  $('#sheet-body').innerHTML = `<div class="body">
      ${ph ? `<img class="lead" src="${photoUrl(ph, true)}" data-gallery="${p.id}" data-index="0" alt="">` : `<div class="noimg">${p.status === 'planned' ? icons.x : (typeIcon(p)?.svg || icons.mori)}</div>`}
      <div><div class="t">${esc(p.title) || '<span style="color:var(--mute)">Untitled</span>'}</div><div class="m">${metaHtml(p)}${n > 1 ? `<br>${n} photos` : ''}</div></div>
      ${n > 1 ? `<div class="strip">${p.photos.slice(1, 7).map((x, i) => `<img src="${photoUrl(x, true)}" data-gallery="${p.id}" data-index="${i + 1}" alt="">`).join('')}</div>` : ''}
      ${p.notes ? `<div class="notes">${esc(p.notes)}</div>` : ''}</div>
    <div class="act"><button type="button" data-link="${p.id}">Copy link</button></div>`;
  $('#sheet').classList.add('on');
}
function closeSheet() { $('#sheet').classList.remove('on'); }
$('#sheet-close').addEventListener('click', closeSheet);
$('#sheet').addEventListener('click', e => { const lk = e.target.closest('[data-link]'); if (lk) copyLink(lk.dataset.link); });
$$('#mnav button').forEach(b => b.addEventListener('click', () => {
  closeSheet(); $('#panel').classList.toggle('open', b.dataset.m === 'list'); setNav(b.dataset.m);
}));
$('#panel-close').addEventListener('click', () => { $('#panel').classList.remove('open'); setNav('map'); });

// ------------------------------------------------------------ photo viewer
const LB = { items: [], i: 0, title: '' };
function showLb() {
  const lb = $('#lightbox'), n = LB.items.length;
  lb.querySelector('img').src = LB.items[LB.i];
  lb.querySelector('.prev').hidden = n < 2; lb.querySelector('.next').hidden = n < 2;
  lb.querySelector('.cap').textContent = (LB.title ? LB.title + '  ·  ' : '') + (n > 1 ? `${LB.i + 1} / ${n}` : '');
}
function lbStep(d) { const n = LB.items.length; if (n < 2) return; LB.i = (LB.i + d + n) % n; showLb(); }
document.addEventListener('click', e => {
  const t = e.target.closest('[data-gallery]'); if (!t) return;
  const p = placements.find(x => x.id === t.dataset.gallery); if (!p || !p.photos?.length) return;
  e.preventDefault(); e.stopPropagation();
  LB.items = p.photos.map(ph => photoUrl(ph)); LB.i = Math.min(+t.dataset.index || 0, LB.items.length - 1); LB.title = p.title || '';
  showLb(); $('#lightbox').classList.add('on');
});
$('#lightbox').addEventListener('click', e => {
  if (e.target.closest('.prev')) return lbStep(-1);
  if (e.target.closest('.next')) return lbStep(1);
  if (e.target.tagName === 'IMG') return;
  $('#lightbox').classList.remove('on');
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') $('#lightbox').classList.remove('on');
  if (!$('#lightbox').classList.contains('on')) return;
  if (e.key === 'ArrowLeft') lbStep(-1); else if (e.key === 'ArrowRight') lbStep(1);
});

boot();
})();
