<?php
/**
 * Activity log: who logged in, who opened the map, and wrong-password
 * attempts. Kept in the site database (option kgs_log), newest first,
 * limited to the most recent KGS_LOG_MAX entries.
 */

if (!defined('ABSPATH')) exit;

define('KGS_OPTION_LOG', 'kgs_log');
define('KGS_LOG_MAX', 1000);
define('KGS_OPEN_GAP', 30 * 60);   // repeat opens by the same person on the same device within this many seconds are one entry

/** A short description of the visitor's device, e.g. "iPhone · Safari". No address is stored. */
function kgs_device_label() {
    $ua = isset($_SERVER['HTTP_USER_AGENT']) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';
    if ($ua === '') return 'Unknown device';
    $device = 'Other';
    foreach (array('iPhone' => 'iPhone', 'iPad' => 'iPad', 'Android' => 'Android', 'Macintosh' => 'Mac', 'Windows' => 'Windows', 'CrOS' => 'Chromebook', 'Linux' => 'Linux') as $needle => $label) {
        if (stripos($ua, $needle) !== false) { $device = $label; break; }
    }
    $browser = 'Other browser';
    foreach (array('Edg/' => 'Edge', 'EdgiOS' => 'Edge', 'OPR/' => 'Opera', 'Firefox' => 'Firefox', 'FxiOS' => 'Firefox', 'CriOS' => 'Chrome', 'Chrome' => 'Chrome', 'Safari' => 'Safari') as $needle => $label) {
        if (strpos($ua, $needle) !== false) { $browser = $label; break; }
    }
    return $device . ' · ' . $browser;
}

function kgs_log_entries() {
    $log = get_option(KGS_OPTION_LOG, array());
    return is_array($log) ? $log : array();
}

/** $event: 'login', 'open' or 'fail'. $person: the person's row, or null for a wrong password. */
function kgs_log_add($event, $person = null) {
    $log = kgs_log_entries();
    $device = kgs_device_label();
    $id = $person ? (string) $person['id'] : '';
    if ($event === 'open') {
        foreach ($log as $row) {                 // newest first
            if ($row['t'] < time() - KGS_OPEN_GAP) break;
            if ($row['id'] === $id && $row['d'] === $device && ($row['e'] === 'open' || $row['e'] === 'login')) return false;
        }
    }
    array_unshift($log, array('t' => time(), 'e' => $event, 'id' => $id, 'n' => $person ? (string) $person['name'] : '', 'd' => $device));
    if (count($log) > KGS_LOG_MAX) $log = array_slice($log, 0, KGS_LOG_MAX);
    update_option(KGS_OPTION_LOG, $log, false);
    return true;
}

/** Record that a logged-in person loaded the map; also keeps their "last opened" time current. */
function kgs_log_open($person) {
    if (!kgs_log_add('open', $person)) return;
    $people = kgs_people();
    foreach ($people as &$p) {
        if ((string) $p['id'] === (string) $person['id']) $p['last_seen'] = time();
    }
    unset($p);
    update_option(KGS_OPTION_PEOPLE, $people, false);
}
