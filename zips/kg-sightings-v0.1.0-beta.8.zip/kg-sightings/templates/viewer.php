<?php
/**
 * The view-only map page. This HTML is identical for every visitor and
 * contains no pin data: viewer.js asks for the data afterwards, and the
 * server only answers once a valid password has been entered.
 */
if (!defined('ABSPATH')) exit;
$kgs_base   = kgs_viewer_url();
$kgs_assets = untrailingslashit(plugins_url('assets', KGS_PLUGIN_FILE));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="robots" content="noindex, nofollow">
<title>Knocking Ghost — Sightings</title>
<link rel="icon" href="<?php echo esc_url($kgs_assets); ?>/icons/mori.svg" type="image/svg+xml">
<link rel="apple-touch-icon" sizes="180x180" href="<?php echo esc_url($kgs_assets); ?>/icons/apple-touch-icon.png">
<meta name="apple-mobile-web-app-title" content="Sightings">
<meta name="theme-color" content="#081a0d">
<link rel="stylesheet" href="<?php echo esc_url($kgs_assets); ?>/vendor/leaflet.css?v=1.9.4">
<link rel="stylesheet" href="<?php echo esc_url($kgs_assets); ?>/vendor/MarkerCluster.css?v=1.5.3">
<style>
  :root {
    --ink: #231f20;
    --paper: #f5f3ee;
    --paper-2: #ebe8e0;
    --line: #cfcbc2;
    --mute: #7a766e;
    --accent: #231f20;
    --panel-w: 360px;
    --mono: ui-monospace, "SF Mono", Menlo, Consolas, "Courier New", monospace;
    --sans: system-ui, -apple-system, "Segoe UI", Helvetica, Arial, sans-serif;
  }
  * { box-sizing: border-box; }
  html, body { height: 100%; margin: 0; }
  body {
    font-family: var(--sans); color: var(--ink); background: var(--paper);
    display: grid; grid-template-columns: var(--panel-w) 1fr; overflow: hidden;
  }

  /* ---------- side panel ---------- */
  #panel {
    display: flex; flex-direction: column; min-height: 0;
    border-right: 1px solid var(--ink); background: var(--paper); z-index: 2;
  }
  #panel header {
    display: flex; align-items: center; gap: 10px; padding: 12px 14px;
    border-bottom: 1px solid var(--ink);
  }
  #panel header img { height: 30px; }
  #panel header h1 { font: 700 13px/1.1 var(--mono); letter-spacing: .14em; margin: 0; text-transform: uppercase; }
  #panel header small { display: block; font: 11px/1.3 var(--mono); color: var(--mute); letter-spacing: .04em; margin-top: 3px; }
  #panel header .ver { margin-left: auto; align-self: flex-start; font: 10px/1 var(--mono); letter-spacing: .08em; color: var(--mute); border: 1px solid var(--line); padding: 3px 5px; border-radius: 2px; white-space: nowrap; }

  .toolbar { display: flex; flex-wrap: wrap; gap: 6px; padding: 10px 14px; border-bottom: 1px solid var(--line); }
  button, .btn {
    font: 12px/1 var(--mono); letter-spacing: .06em; text-transform: uppercase;
    background: var(--paper); color: var(--ink); border: 1px solid var(--ink);
    padding: 8px 10px; cursor: pointer; border-radius: 2px;
  }
  button:hover, .btn:hover { background: var(--ink); color: var(--paper); }
  button.primary { background: var(--ink); color: var(--paper); }
  button.primary:hover { background: #000; }
  button.danger { border-color: #9a2a2a; color: #9a2a2a; }
  button.danger:hover { background: #9a2a2a; color: #fff; }
  button:disabled { opacity: .4; cursor: default; }
  button.active { background: var(--ink); color: var(--paper); }

  .filters { display: flex; gap: 6px; padding: 10px 14px; border-bottom: 1px solid var(--line); align-items: center; }
  .chip {
    display: inline-flex; align-items: center; gap: 6px; font: 11px/1 var(--mono); letter-spacing: .06em;
    text-transform: uppercase; border: 1px solid var(--ink); padding: 6px 8px; cursor: pointer; user-select: none; border-radius: 2px;
  }
  .chip input { display: none; }
  .chip.off { opacity: .4; border-style: dashed; }
  .chip .n { color: var(--mute); }
  .chip.off .n { color: inherit; }

  .search { padding: 10px 14px; border-bottom: 1px solid var(--line); }
  input, select, textarea {
    font: 13px/1.3 var(--sans); color: var(--ink); background: #fff; border: 1px solid var(--line);
    padding: 7px 8px; width: 100%; border-radius: 2px;
  }
  input:focus, select:focus, textarea:focus { outline: none; border-color: var(--ink); }
  textarea { min-height: 90px; resize: vertical; }

  #browse { display: flex; flex-direction: column; flex: 1; min-height: 0; }
  #browse.hidden { display: none; }
  #list { flex: 1; overflow: auto; min-height: 0; }
  .item {
    display: grid; grid-template-columns: 56px 1fr; gap: 10px; padding: 10px 14px;
    border-bottom: 1px solid var(--line); cursor: pointer;
  }
  .item:hover { background: var(--paper-2); }
  .item.selected { background: var(--ink); color: var(--paper); }
  .item.selected .meta { color: var(--line); }
  .item.selected .dot { background: var(--paper); }
  .item.selected .dot.planned { background: transparent; }
  .item .thumb { width: 56px; height: 56px; object-fit: cover; background: var(--paper-2); border: 1px solid var(--line); }
  .item .thumb.empty { display: grid; place-items: center; }
  .item .thumb.empty svg { height: 32px; width: auto; opacity: .55; }
  .item { grid-template-columns: 56px 1fr auto; }
  .item .ticon { width: 36px; height: 40px; align-self: center; display: grid; place-items: center; }
  .item .ticon svg { display: block; width: auto; height: 38px; max-width: 36px; }
  .item .ticon.gone svg { opacity: .4; }
  .item.selected .ticon.planned svg [fill] { fill: var(--paper); }
  .item .title { font-weight: 600; font-size: 13px; display: flex; gap: 6px; align-items: center; }
  .item .meta { font: 11px/1.4 var(--mono); color: var(--mute); margin-top: 3px; }
  .dot { width: 8px; height: 8px; border-radius: 50%; display: inline-block; background: var(--ink); flex: none; }
  .dot.planned { background: transparent; border: 1.5px solid currentColor; }
  .dot.gone { opacity: .35; }
  .empty-state { padding: 30px 18px; color: var(--mute); font: 12px/1.6 var(--mono); }

  #panel footer { padding: 8px 14px; border-top: 1px solid var(--line); font: 10px/1.4 var(--mono); color: var(--mute); display: flex; justify-content: space-between; }

  /* ---------- edit form ---------- */
  #editor { display: none; flex-direction: column; min-height: 0; flex: 1; }
  #editor.open { display: flex; }
  #editor .head { display: flex; align-items: center; justify-content: space-between; padding: 10px 14px; border-bottom: 1px solid var(--ink); }
  #editor .head h2 { font: 700 12px/1 var(--mono); letter-spacing: .12em; text-transform: uppercase; margin: 0; }
  #editor form { flex: 1; overflow: auto; padding: 12px 14px; display: flex; flex-direction: column; gap: 10px; }
  label.f { display: block; font: 10px/1 var(--mono); letter-spacing: .1em; text-transform: uppercase; color: var(--mute); margin-bottom: 4px; }
  .row { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
  .seg { display: flex; border: 1px solid var(--ink); border-radius: 2px; overflow: hidden; }
  .seg label { flex: 1; text-align: center; font: 11px/1 var(--mono); letter-spacing: .06em; text-transform: uppercase; padding: 8px 4px; cursor: pointer; border-right: 1px solid var(--ink); }
  .seg label:last-child { border-right: 0; }
  .seg input { display: none; }
  .seg label:has(input:checked) { background: var(--ink); color: var(--paper); }
  .inline { display: flex; gap: 6px; }
  .inline input { flex: 1; }
  .hint { font: 11px/1.4 var(--mono); color: var(--mute); }
  .photos { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px; }
  .photos .ph { position: relative; aspect-ratio: 1; border: 1px solid var(--line); background: var(--paper-2); }
  .photos .ph img { width: 100%; height: 100%; object-fit: cover; display: block; cursor: zoom-in; }
  .photos .ph .rm { position: absolute; top: 4px; right: 4px; width: 20px; height: 20px; padding: 0; font-size: 12px; line-height: 18px; }
  .photos .ph { cursor: grab; }
  .photos .ph.drag-over { outline: 2px solid var(--ink); outline-offset: -2px; }
  .photos .ph.dragging { opacity: .4; }
  .photos .ph .lead { position: absolute; top: 4px; left: 4px; font: 700 9px/1 var(--mono); letter-spacing: .1em; background: var(--ink); color: var(--paper); padding: 4px 5px; border-radius: 2px; }
  .photos .ph .bar { position: absolute; left: 0; right: 0; bottom: 0; display: flex; background: rgba(245,243,238,.92); border-top: 1px solid var(--line); }
  .photos .ph .bar button { flex: 1; border: 0; border-right: 1px solid var(--line); padding: 5px 0; font-size: 11px; background: transparent; }
  .photos .ph .bar button:last-child { border-right: 0; }
  .photos .ph .bar button:hover { background: var(--ink); color: var(--paper); }
  .photos .ph .bar button:disabled { opacity: .25; }
  .photos .add { display: grid; place-items: center; aspect-ratio: 1; border: 1px dashed var(--ink); cursor: pointer; font: 11px/1.3 var(--mono); text-align: center; letter-spacing: .06em; text-transform: uppercase; }
  .photos .add:hover { background: var(--paper-2); }
  #editor .actions { display: flex; gap: 6px; padding: 10px 14px; border-top: 1px solid var(--ink); }
  #editor .actions .spacer { flex: 1; }

  /* ---------- map ---------- */
  #map { height: 100vh; background: #e9e7e1; }
  #map.adding { cursor: crosshair; }
  .leaflet-container { font-family: var(--sans); }
  .tiles-bw { filter: grayscale(1) contrast(1.12) brightness(1.02); }
  body.tint-dark .kg-marker.planned svg [fill], body.tint-dark #crosshair .x svg [fill] { fill: var(--x-dark, #eaf7e6); }
  body.tint-dark .kg-marker svg { filter: drop-shadow(0 0 calc(2px * var(--halo, 1)) rgba(0,0,0,calc(.8 * min(1, var(--halo, 1))))); }
  body.tint-dark .kg-marker.selected svg { filter: drop-shadow(0 0 0 2px #fff) drop-shadow(0 0 6px rgba(255,255,255,.6)); }
  .leaflet-control-layers, .leaflet-bar, .leaflet-control-attribution { border-radius: 2px !important; box-shadow: none !important; border: 1px solid var(--ink) !important; }
  .leaflet-control-layers { font: 12px/1.4 var(--mono); }
  .leaflet-bar a { color: var(--ink); }
  .leaflet-control-attribution { font: 10px/1.3 var(--mono); background: rgba(245,243,238,.9) !important; }

  .kg-marker { background: none; border: none; }
  .kg-marker svg { display: block; width: 100%; height: 100%; filter: drop-shadow(0 1px calc(1px * var(--halo, 1)) rgba(0,0,0,calc(.35 * var(--halo, 1)))); }
  .kg-marker.gone svg { opacity: var(--gone-opacity, .35); }
  .kg-marker.selected svg { filter: drop-shadow(0 0 0 2px #fff) drop-shadow(0 0 4px rgba(0,0,0,.9)); }
  .kg-marker.dragging svg { transform: scale(1.15); }
  .kg-cluster { width: 100%; height: 100%; background: var(--paper); border: 1.5px solid var(--ink); border-radius: 50%; display: grid; place-items: center; font: 700 12px var(--mono); color: var(--ink); box-shadow: 0 1px 2px rgba(0,0,0,.3); }

  .leaflet-popup-content-wrapper { border-radius: 2px; border: 1px solid var(--ink); box-shadow: 0 2px 6px rgba(0,0,0,.2); padding: 0; }
  .leaflet-popup-content { margin: 0; width: 240px !important; }
  .leaflet-popup-tip { border: 1px solid var(--ink); }
  .pop img { width: 100%; height: 160px; object-fit: cover; display: block; border-bottom: 1px solid var(--ink); cursor: zoom-in; }
  .pop .body { padding: 10px 12px; }
  .pop .t { font-weight: 700; font-size: 13px; margin-bottom: 4px; }
  .pop .m { font: 11px/1.5 var(--mono); color: var(--mute); }
  .pop .m b { color: var(--ink); font-weight: 600; }
  .pop .notes { font-size: 12px; margin-top: 6px; white-space: pre-wrap; max-height: 80px; overflow: auto; }
  .pop .strip { display: flex; gap: 3px; padding: 6px 12px 0; }
  .pop .strip img { width: 40px; height: 40px; object-fit: cover; border: 1px solid var(--line); cursor: zoom-in; }
  .pop .strip img:hover { border-color: var(--ink); }
  .pop .strip .more { width: 40px; height: 40px; display: grid; place-items: center; font: 11px var(--mono); border: 1px dashed var(--line); color: var(--mute); cursor: zoom-in; }
  .pop .act { display: flex; gap: 6px; margin-top: 10px; }
  .pop .act button { padding: 6px 8px; font-size: 11px; }

  .geo-ctl input { width: 220px; font: 12px var(--mono); padding: 6px 8px; border: 0; }
  .geo-ctl { background: var(--paper); }

  /* ---------- overlays ---------- */
  #drop {
    position: fixed; inset: 0; display: none; place-items: center; z-index: 5000;
    background: rgba(35,31,32,.75); color: var(--paper); font: 700 16px/1.5 var(--mono); letter-spacing: .12em; text-transform: uppercase; text-align: center; pointer-events: none;
  }
  #drop.on { display: grid; }
  #drop .box { border: 2px dashed var(--paper); padding: 40px 60px; }
  #drop img { height: 90px; display: block; margin: 0 auto 14px; }

  #toast { position: fixed; left: 50%; bottom: 24px; transform: translateX(-50%); background: var(--ink); color: var(--paper); font: 12px/1.4 var(--mono); padding: 10px 16px; border-radius: 2px; z-index: 6000; display: none; max-width: 80vw; }
  #toast.on { display: block; }

  #modal { position: fixed; inset: 0; display: none; place-items: center; background: rgba(35,31,32,.6); z-index: 6500; }
  #modal.on { display: grid; }
  #modal .card { background: var(--paper); border: 1px solid var(--ink); padding: 18px; width: 340px; max-width: 90vw; font-size: 13px; line-height: 1.5; }
  #modal .card .btns { display: flex; flex-direction: column; gap: 6px; margin-top: 14px; }

  #lightbox { position: fixed; inset: 0; display: none; place-items: center; background: rgba(0,0,0,.92); z-index: 7000; cursor: zoom-out; }
  #lightbox.on { display: grid; }
  #lightbox img { max-width: 94vw; max-height: 90vh; cursor: default; }
  #lightbox .nav { position: absolute; top: 50%; transform: translateY(-50%); width: 48px; height: 72px; border: 0; background: rgba(245,243,238,.12); color: #fff; font-size: 30px; line-height: 1; padding: 0; cursor: pointer; }
  #lightbox .nav:hover { background: rgba(245,243,238,.3); }
  #lightbox .nav.prev { left: 10px; } #lightbox .nav.next { right: 10px; }
  #lightbox .nav[hidden] { display: none; }
  #lightbox .close { position: absolute; top: 10px; right: 10px; border: 0; background: transparent; color: #fff; font-size: 22px; cursor: pointer; padding: 6px 10px; }
  #lightbox .close:hover { background: rgba(245,243,238,.2); }
  #lightbox .cap { position: absolute; left: 0; right: 0; bottom: 12px; text-align: center; font: 11px/1.4 var(--mono); letter-spacing: .08em; color: var(--line); pointer-events: none; }

  #panel-toggle { display: none; }

  /* ---------- workbench (Shift+W) ---------- */
  #wb { position: fixed; top: 12px; right: 12px; width: 400px; max-height: calc(100vh - 24px); overflow: auto; background: #fff; color: #17263f; border: 3px solid #17263f; box-shadow: 10px 10px 0 rgba(23,38,63,.15); z-index: 6000; font: 13px/1.4 var(--mono); display: none; }
  #wb.on { display: block; }
  #wb .hd { display: flex; align-items: center; gap: 8px; padding: 14px 16px 8px; }
  #wb .hd h2 { margin: 0; font: 700 15px/1 var(--mono); letter-spacing: .14em; }
  #wb .hd .v { color: #8b93a3; font-size: 12px; }
  #wb .hd .x { margin-left: auto; border: 0; background: none; font-size: 18px; padding: 2px 6px; color: #17263f; }
  #wb .hd .x:hover { background: #17263f; color: #fff; }
  #wb h3 { margin: 10px 16px 2px; font: 700 10px/1 var(--mono); letter-spacing: .14em; text-transform: uppercase; color: #8b93a3; border-top: 1px solid #e3e6ec; padding-top: 10px; }
  #wb .row { display: grid; grid-template-columns: 1fr 48px 110px; gap: 8px; align-items: center; padding: 5px 16px; }
  #wb .row.sl { grid-template-columns: 1fr 150px 44px; }
  #wb .row label { font-size: 12.5px; }
  #wb input[type=color] { width: 48px; height: 32px; padding: 2px; border: 2px solid #17263f; border-radius: 3px; background: #fff; cursor: pointer; }
  #wb input[type=text] { font: 13px var(--mono); border: 2px solid #17263f; padding: 6px 8px; text-transform: uppercase; }
  #wb input[type=range] { width: 100%; accent-color: #17263f; }
  #wb select { font: 12px var(--mono); border: 2px solid #17263f; padding: 5px; background: #fff; }
  #wb .val { text-align: right; font-size: 12px; }
  #wb .ft { display: flex; align-items: center; gap: 8px; padding: 12px 16px 16px; border-top: 1px solid #e3e6ec; margin-top: 8px; }
  #wb .ft .spacer { flex: 1; }
  #wb .ft button { font: 700 13px var(--mono); letter-spacing: .1em; padding: 12px 18px; border: 2px solid #17263f; background: #fff; color: #17263f; border-radius: 0; }
  #wb .ft button.reset { border-style: dashed; }
  #wb .ft button.deploy { background: #17263f; color: #8ad0f0; }
  #wb .ft button:hover { background: #17263f; color: #fff; }
  #wb .note { padding: 4px 16px 0; font-size: 11px; color: #8b93a3; }
  #wb .pw { display: none; gap: 8px; padding: 8px 16px 0; align-items: center; }
  #wb .pw.on { display: flex; }
  #wb .pw input { flex: 1; font: 13px var(--mono); border: 2px solid #17263f; padding: 8px; }
  #wb .msg { padding: 6px 16px 0; font-size: 12px; min-height: 18px; }
  #wb .msg.err { color: #9a2a2a; } #wb .msg.ok { color: #1f7a3a; }

  #panel-close, #mnav, #sheet, #addmenu, #crosshair, .mobile-only { display: none; }
  @media (max-width: 760px) { .desktop-only { display: none; } #ed-loc { display: flex !important; } }
  @media (max-width: 760px) {
    html, body { position: fixed; inset: 0; width: 100%; height: 100%; overscroll-behavior: none; -webkit-user-select: none; user-select: none; }
    body { grid-template-columns: 1fr; grid-template-rows: 1fr; }
    .mobile-only { display: initial; }
    #map { height: 100%; touch-action: none; }
    .leaflet-control-zoom, .geo-ctl, #panel-toggle, #wb, .leaflet-control-scale { display: none !important; }
    .leaflet-top.leaflet-right { top: env(safe-area-inset-top); }
    .leaflet-control-attribution { font-size: 9px; margin-bottom: calc(60px + env(safe-area-inset-bottom)) !important; }
    #toast { bottom: calc(76px + env(safe-area-inset-bottom)); }

    /* bottom tab bar */
    #mnav { display: grid; grid-template-columns: 1fr 1fr 1fr; position: fixed; left: 0; right: 0; bottom: 0; z-index: 1300; background: var(--paper); border-top: 1px solid var(--ink); padding-bottom: env(safe-area-inset-bottom); }
    #mnav button { border: 0; border-right: 1px solid var(--line); border-radius: 0; background: transparent; padding: 12px 0 10px; font: 11px/1 var(--mono); letter-spacing: .1em; text-transform: uppercase; color: var(--mute); display: flex; flex-direction: column; align-items: center; gap: 5px; }
    #mnav button:last-child { border-right: 0; }
    #mnav button .ic { font-size: 18px; line-height: 1; }
    #mnav button.active { color: var(--ink); }
    #mnav button:hover { background: transparent; color: var(--ink); }

    /* list / editor panel fills the screen above the tab bar */
    #panel { position: fixed; inset: 0; bottom: calc(52px + env(safe-area-inset-bottom)); width: 100%; min-width: 0; border-right: 0; z-index: 1100; transform: translateX(-100%); transition: transform .2s; }
    #panel.open { transform: none; }
    #panel header { padding-top: calc(12px + env(safe-area-inset-top)); }
    #panel-close { display: inline-block; margin-left: auto; }
    #panel header .ver { display: none; }
    .toolbar { display: none; }                         /* actions live in the + Add tab on phones */
    #panel footer { display: none; }
    input, select, textarea { font-size: 16px; }         /* stops iOS zooming into fields */
    #editor .actions { padding-bottom: 14px; }
    .item { padding: 12px 14px; }

    /* pin card */
    #sheet { display: block; position: fixed; left: 0; right: 0; bottom: calc(52px + env(safe-area-inset-bottom)); z-index: 1200; background: var(--paper); border-top: 1px solid var(--ink); transform: translateY(110%); transition: transform .22s; max-height: 70vh; overflow: auto; box-shadow: 0 -4px 16px rgba(0,0,0,.25); }
    #sheet.on { transform: none; }
    #sheet .grab { width: 40px; height: 4px; background: var(--line); border-radius: 2px; margin: 8px auto 0; }
    #sheet .body { display: grid; grid-template-columns: 112px 1fr; gap: 12px; padding: 10px 14px 12px; }
    #sheet .body img.lead { width: 112px; height: 112px; object-fit: cover; border: 1px solid var(--ink); background: var(--paper-2); cursor: zoom-in; }
    #sheet .body .noimg { width: 112px; height: 112px; display: grid; place-items: center; border: 1px solid var(--line); background: var(--paper-2); }
    #sheet .body .noimg svg { height: 60px; width: auto; opacity: .5; }
    #sheet .t { font-weight: 700; font-size: 15px; margin-bottom: 4px; }
    #sheet .m { font: 11px/1.5 var(--mono); color: var(--mute); }
    #sheet .m b { color: var(--ink); font-weight: 600; }
    #sheet .notes { grid-column: 1 / 3; font-size: 13px; white-space: pre-wrap; max-height: 90px; overflow: auto; padding: 0 14px; }
    #sheet .strip { grid-column: 1 / 3; display: flex; gap: 4px; padding: 0 14px; }
    #sheet .strip img { width: 44px; height: 44px; object-fit: cover; border: 1px solid var(--line); }
    #sheet .act { display: flex; gap: 6px; padding: 6px 14px 14px; }
    #sheet .act button { flex: 1; padding: 11px 6px; }
    #sheet .x { position: absolute; top: 6px; right: 8px; border: 0; background: transparent; font-size: 20px; padding: 4px 8px; }

    /* + Add menu */
    #addmenu { display: block; position: fixed; left: 10px; right: 10px; bottom: calc(62px + env(safe-area-inset-bottom)); z-index: 1250; background: var(--paper); border: 1px solid var(--ink); box-shadow: 0 6px 20px rgba(0,0,0,.3); transform: translateY(20px); opacity: 0; pointer-events: none; transition: all .18s; }
    #addmenu.on { transform: none; opacity: 1; pointer-events: auto; }
    #addmenu .am-note { padding: 12px 16px; font: 12px/1.45 var(--sans); background: var(--ink); color: var(--paper); }
    #addmenu .am-note b { color: #8ff489; }
    #addmenu button { display: block; width: 100%; text-align: left; border: 0; border-bottom: 1px solid var(--line); border-radius: 0; padding: 15px 16px; font-size: 12px; }
    #addmenu button:last-child { border-bottom: 0; }
    #addmenu button small { display: block; text-transform: none; letter-spacing: 0; font: 11px/1.3 var(--sans); color: var(--mute); margin-top: 3px; }
    #addmenu button:hover small { color: var(--paper); }

    /* crosshair "mark the map centre" mode */
    #crosshair { display: none; position: fixed; inset: 0; bottom: calc(52px + env(safe-area-inset-bottom)); z-index: 1150; pointer-events: none; }
    #crosshair.on { display: block; }
    #crosshair .x { position: absolute; left: 50%; top: 50%; width: 44px; height: 44px; transform: translate(-50%, -50%); }
    #crosshair .x svg { width: 100%; height: 100%; filter: drop-shadow(0 0 3px rgba(0,0,0,.6)); }
    #crosshair .bar { position: absolute; left: 10px; right: 10px; bottom: 10px; display: flex; gap: 6px; pointer-events: auto; }
    #crosshair .bar button { flex: 1; padding: 13px; }
    #crosshair .hint { position: absolute; top: calc(12px + env(safe-area-inset-top)); left: 10px; right: 60px; background: var(--ink); color: var(--paper); font: 11px/1.4 var(--mono); padding: 8px 10px; }
  }

  /* ---------- view-only additions ---------- */
  #panel footer a { color: var(--mute); }
  #panel footer a:hover { color: var(--ink); }
  #gate { position: fixed; inset: 0; z-index: 9000; display: none; place-items: center; background: #081a0d; padding: 20px; }
  #gate.on { display: grid; }
  #gate form { width: 100%; max-width: 340px; text-align: center; background: #f5f3ee; color: #231f20; border: 1px solid #231f20; padding: 30px 26px 24px; box-shadow: 0 0 0 6px rgba(143,244,137,.12); }
  #gate img { height: 84px; }
  #gate h2 { font: 700 14px/1.1 var(--mono); letter-spacing: .16em; text-transform: uppercase; margin: 12px 0 4px; }
  #gate p { font: 11px/1.4 var(--mono); color: #7a766e; letter-spacing: .06em; margin: 0 0 18px; }
  #gate input { text-align: center; font: 16px/1.3 var(--mono); letter-spacing: .08em; padding: 11px; border: 1px solid #231f20; }
  #gate button { width: 100%; margin-top: 10px; padding: 12px; }
  #gate-err { min-height: 18px; margin-top: 12px; font: 11px/1.4 var(--mono); color: #9a2a2a; }
  @media (max-width: 760px) { #mnav.two { grid-template-columns: 1fr 1fr; } }
</style>
</head>
<body class="kgs">

<div id="panel">
  <header>
    <img src="<?php echo esc_url($kgs_assets); ?>/icons/mori.svg" alt="">
    <div>
      <h1>Knocking Ghost</h1>
      <small>Sightings</small>
    </div>
    <button type="button" id="panel-close" title="Back to the map">Map ›</button>
  </header>
  <div id="browse">
    <div class="filters" id="filters" hidden></div>
    <div class="search"><input id="q" type="search" placeholder="Search title, type…"></div>
    <div id="list"></div>
    <footer><span id="count"></span><a id="logout" href="<?php echo esc_url($kgs_base); ?>?kgs=logout">Log out</a></footer>
  </div>
</div>

<div id="map"></div>

<nav id="mnav" class="two">
  <button type="button" data-m="map" class="active"><span class="ic">◎</span>Map</button>
  <button type="button" data-m="list"><span class="ic">☰</span>List</button>
</nav>
<div id="sheet"><button type="button" class="x" id="sheet-close">×</button><div class="grab"></div><div id="sheet-body"></div></div>
<div id="toast"></div>
<div id="lightbox"><img alt=""><button type="button" class="nav prev" aria-label="Previous">‹</button><button type="button" class="nav next" aria-label="Next">›</button><button type="button" class="close" aria-label="Close">×</button><div class="cap"></div></div>

<div id="gate">
  <form id="gate-form" autocomplete="off">
    <img src="<?php echo esc_url($kgs_assets); ?>/icons/mori.svg" alt="">
    <h2>Knocking Ghost</h2>
    <p>Sightings · by invitation</p>
    <input type="password" id="gate-pass" placeholder="password" autocomplete="current-password" autocapitalize="off" autocorrect="off" spellcheck="false">
    <button type="submit" class="primary">Enter</button>
    <div id="gate-err"></div>
  </form>
</div>

<script>window.KGS = <?php echo wp_json_encode(array('base' => $kgs_base, 'assets' => $kgs_assets, 'version' => KGS_VERSION)); ?>;</script>
<script src="<?php echo esc_url($kgs_assets); ?>/vendor/leaflet.js?v=1.9.4"></script>
<script src="<?php echo esc_url($kgs_assets); ?>/vendor/leaflet.markercluster.js?v=1.5.3"></script>
<script src="<?php echo esc_url($kgs_assets); ?>/viewer.js?v=<?php echo esc_attr(KGS_VERSION); ?>"></script>
</body>
</html>
