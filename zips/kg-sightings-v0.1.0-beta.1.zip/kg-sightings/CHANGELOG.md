# Changelog

## 0.1.0-beta.1
First build: view-only map at /sightings/ with a password-only login, one password per person (Settings → KG Sightings), reading the private map's pins, photos and look without being able to change them.

- Viewers see placed pieces only by default; planned spots, "gone" pieces, written addresses and notes are each a switch.
- Photos are sent only for pins the viewer is allowed to see.
- Removing a person or changing their password ends their logins at once.
- 8 wrong passwords from one address pause logins from it for 15 minutes.
- Self-updater (beta/stable channels, check-now, rollback) from the first version.
