=== KG Sightings ===
Contributors: chrisjennings
Requires at least: 5.5
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 0.1.0-beta.1

View-only version of the Knocking Ghost placement map, behind a password-only login with one password per person.

== What it does ==
* Serves a view-only map at /sightings/ (the address can be changed in the settings).
* Reads the pins, photos and look of the private map in public_html/map/. It never writes to that folder.
* Login is one password field, no username. Each person has their own password, set under Settings → KG Sightings.
* By default viewers see placed pieces only, without the written address or your notes. Planned spots, "gone" pieces, addresses and notes can each be switched on.

== Install ==
1. Plugins → Add New → Upload Plugin → choose the kg-sightings zip → Install Now → Activate.
2. Settings → KG Sightings → add a person (a name for your own reference, and their password).
3. Send them the address shown at the top of that page, and their password.
4. Once only: SiteGround Site Tools → Speed → Caching → Dynamic Cache → Exclude URLs → add /sightings/*

(No "Save Permalinks" step needed.)

== Update ==
KG Sightings updates itself from its own GitHub release channel. New builds appear as a normal
"update available" row on the Plugins screen. The plugin's row also has "Check for updates",
"Switch to beta/stable channel" and "Roll back to X".

== Good to know ==
* Passwords are stored in a one-way form. The settings page shows a password once, when you set it.
* Removing a person, or giving them a new password, logs out every browser they were logged in on.
* 8 wrong passwords from one internet address pause logins from that address for 15 minutes.
* If the site's secret keys in wp-config.php are ever changed, every password needs setting again.
