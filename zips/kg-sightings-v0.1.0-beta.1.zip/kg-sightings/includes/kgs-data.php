<?php
/**
 * Read-only access to the private map's files (public_html/map/).
 * Nothing in this file writes, moves or deletes anything in that folder.
 */

if (!defined('ABSPATH')) exit;

/** Absolute path of the private map folder, or '' when it cannot be found. */
function kgs_map_dir($s) {
    $rel = trim(str_replace('\\', '/', (string) $s['map_dir']), '/');
    if ($rel === '' || strpos($rel, '..') !== false) return '';
    $dir = rtrim(ABSPATH, '/') . '/' . $rel;
    return is_dir($dir) ? $dir : '';
}

/** Pins a viewer is allowed to see, with only the fields they are allowed to see. */
function kgs_visible_placements($s) {
    $dir = kgs_map_dir($s);
    if ($dir === '' || !is_file($dir . '/data/placements.json')) return array();
    $doc = json_decode((string) file_get_contents($dir . '/data/placements.json'), true);
    if (!is_array($doc) || empty($doc['placements']) || !is_array($doc['placements'])) return array();

    $out = array();
    foreach ($doc['placements'] as $p) {
        if (!is_array($p) || !isset($p['lat'], $p['lng'])) continue;
        $status = isset($p['status']) ? (string) $p['status'] : 'placed';
        if ($status === 'planned' && empty($s['show_planned'])) continue;
        if ($status === 'gone' && empty($s['show_gone'])) continue;
        if (!in_array($status, array('placed', 'planned', 'gone'), true)) continue;

        $photos = array();
        foreach ((array) (isset($p['photos']) ? $p['photos'] : array()) as $ph) {
            $f = isset($ph['file']) ? basename((string) $ph['file']) : '';
            $t = isset($ph['thumb']) ? basename((string) $ph['thumb']) : '';
            if ($f === '' || !preg_match('/^[a-z0-9_-]+\.(jpe?g|png|webp)$/i', $f)) continue;
            if ($t !== '' && !preg_match('/^[a-z0-9_-]+\.(jpe?g|png|webp)$/i', $t)) $t = '';
            $photos[] = array('file' => $f, 'thumb' => $t);
        }

        $row = array(
            'id'        => isset($p['id']) ? (string) $p['id'] : '',
            'title'     => isset($p['title']) ? (string) $p['title'] : '',
            'status'    => $status,
            'type'      => isset($p['type']) ? (string) $p['type'] : '',
            'lat'       => (float) $p['lat'],
            'lng'       => (float) $p['lng'],
            'placed_at' => isset($p['placed_at']) ? (string) $p['placed_at'] : '',
            'photos'    => $photos,
        );
        if ($status === 'gone') $row['last_seen'] = isset($p['last_seen']) ? (string) $p['last_seen'] : '';
        if (!empty($s['show_address'])) $row['address'] = isset($p['address']) ? (string) $p['address'] : '';
        if (!empty($s['show_notes']))   $row['notes']   = isset($p['notes']) ? (string) $p['notes'] : '';
        $out[] = $row;
    }
    return $out;
}

/** An SVG file from the map's icons folder (falls back to the copy shipped with the plugin). */
function kgs_read_icon($dir, $name) {
    $name = basename((string) $name);
    if (!preg_match('/^[a-z0-9_-]+\.svg$/i', $name)) return '';
    $candidates = array(dirname(__DIR__) . '/assets/icons/' . $name);
    if ($dir !== '') array_unshift($candidates, $dir . '/icons/' . $name);
    foreach ($candidates as $f) {
        if (is_file($f)) return (string) file_get_contents($f);
    }
    return '';
}

/** Values the private map keeps in config.js that the viewer also needs. */
function kgs_read_config($dir) {
    $cfg = array('stadia' => '', 'center' => array(41.9068, -87.6780), 'zoom' => 14, 'tint' => 'phosphor', 'type_icons' => array('sticker' => array('file' => 'mori-sticker.svg', 'size' => 42)), 'basemap' => 'toner');
    $f = $dir . '/config.js';
    if ($dir === '' || !is_file($f)) return $cfg;
    $js = (string) file_get_contents($f);
    if (preg_match('/STADIA_API_KEY\s*:\s*"([^"]*)"/', $js, $m)) $cfg['stadia'] = trim($m[1]);
    if (preg_match('/DEFAULT_CENTER\s*:\s*\[\s*(-?[\d.]+)\s*,\s*(-?[\d.]+)\s*\]/', $js, $m)) $cfg['center'] = array((float) $m[1], (float) $m[2]);
    if (preg_match('/DEFAULT_ZOOM\s*:\s*(\d+)/', $js, $m)) $cfg['zoom'] = (int) $m[1];
    if (preg_match('/MAP_TINT\s*:\s*"([a-z]+)"/', $js, $m)) $cfg['tint'] = $m[1];
    if (preg_match('/DEFAULT_BASEMAP\s*:\s*"([a-z-]+)"/', $js, $m)) $cfg['basemap'] = $m[1];
    if (preg_match('/TYPE_ICONS\s*:\s*\{(.*?)\n\s*\}/s', $js, $block)
        && preg_match_all('/"([^"]+)"\s*:\s*\{\s*file\s*:\s*"([^"]+)"\s*(?:,\s*size\s*:\s*(\d+))?/', $block[1], $mm, PREG_SET_ORDER)) {
        $cfg['type_icons'] = array();
        foreach ($mm as $row) $cfg['type_icons'][strtolower(trim($row[1]))] = array('file' => basename($row[2]), 'size' => isset($row[3]) && $row[3] !== '' ? (int) $row[3] : 40);
    }
    return $cfg;
}

/** Everything the viewer page needs, in one response. */
function kgs_build_payload($s) {
    $dir = kgs_map_dir($s);
    $cfg = kgs_read_config($dir);

    $look = array();
    if ($dir !== '' && is_file($dir . '/data/settings.json')) {
        $raw = json_decode((string) file_get_contents($dir . '/data/settings.json'), true);
        foreach (array('tint', 'pins', 'ui') as $group) {
            if (isset($raw[$group]) && is_array($raw[$group])) {
                $look[$group] = array_filter($raw[$group], 'is_scalar');
            }
        }
    }

    $types = array();
    foreach ($cfg['type_icons'] as $type => $def) {
        $svg = kgs_read_icon($dir, $def['file']);
        if ($svg !== '') $types[$type] = array('svg' => $svg, 'size' => (int) $def['size']);
    }

    return array(
        'ok'         => true,
        'placements' => kgs_visible_placements($s),
        'look'       => (object) $look,
        'config'     => array('stadia' => $cfg['stadia'], 'center' => $cfg['center'], 'zoom' => $cfg['zoom'], 'tint' => $cfg['tint'], 'basemap' => $cfg['basemap']),
        'icons'      => array('mori' => kgs_read_icon($dir, 'mori.svg'), 'x' => kgs_read_icon($dir, 'x.svg'), 'types' => (object) $types),
        'found'      => $dir !== '',
    );
}

/** Send one photo, only if it belongs to a pin this viewer is allowed to see. */
function kgs_send_photo($s, $name) {
    $name = basename((string) $name);
    $dir  = kgs_map_dir($s);
    $ok   = false;
    if ($dir !== '' && preg_match('/^[a-z0-9_-]+\.(jpe?g|png|webp)$/i', $name)) {
        foreach (kgs_visible_placements($s) as $p) {
            foreach ($p['photos'] as $ph) {
                if ($ph['file'] === $name || $ph['thumb'] === $name) { $ok = true; break 2; }
            }
        }
    }
    $file = $dir . '/photos/' . $name;
    if (!$ok || !is_file($file)) { kgs_no_cache(); status_header(404); return; }

    $ext  = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $mime = $ext === 'png' ? 'image/png' : ($ext === 'webp' ? 'image/webp' : 'image/jpeg');
    status_header(200);
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . filesize($file));
    header('Cache-Control: private, max-age=604800');   // the viewer's own browser may keep it; shared caches may not
    header('X-Cache-Enabled: False');
    header('X-Robots-Tag: noindex, nofollow');
    header('X-Content-Type-Options: nosniff');
    readfile($file);
}
