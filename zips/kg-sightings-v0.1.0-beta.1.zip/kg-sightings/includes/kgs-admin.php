<?php
/**
 * Settings → KG Sightings: the list of people and their passwords,
 * and what viewers are allowed to see.
 */

if (!defined('ABSPATH')) exit;

add_action('admin_menu', function () {
    add_options_page('KG Sightings', 'KG Sightings', 'manage_options', 'kg-sightings', 'kgs_render_admin');
});

add_filter('plugin_action_links_' . plugin_basename(KGS_PLUGIN_FILE), function ($links) {
    array_unshift($links, '<a href="' . esc_url(admin_url('options-general.php?page=kg-sightings')) . '">People &amp; settings</a>');
    return $links;
});

/** Handle the forms on the settings page. Returns array(type, message) or null. */
function kgs_admin_handle_post() {
    if (empty($_POST['kgs_action'])) return null;
    if (!current_user_can('manage_options')) return array('error', 'You are not allowed to change these settings.');
    check_admin_referer('kgs_admin');

    $action = sanitize_key(wp_unslash($_POST['kgs_action']));
    $people = kgs_people();

    if ($action === 'add' || $action === 'reset') {
        $pass = isset($_POST['kgs_password']) ? trim((string) wp_unslash($_POST['kgs_password'])) : '';
        if (strlen($pass) < 6) return array('error', 'The password needs at least 6 characters.');
        $hash = kgs_hash_password($pass);
        $id   = $action === 'reset' ? sanitize_key(wp_unslash(isset($_POST['kgs_id']) ? $_POST['kgs_id'] : '')) : '';
        foreach ($people as $p) {
            if (hash_equals((string) $p['hash'], $hash) && (string) $p['id'] !== $id) {
                return array('error', 'Someone else already has that password. Each person needs a different one, because the password is what tells the map who is logging in.');
            }
        }
        if ($action === 'add') {
            $name = sanitize_text_field(wp_unslash(isset($_POST['kgs_name']) ? $_POST['kgs_name'] : ''));
            if ($name === '') return array('error', 'Type a name so you can tell the passwords apart later.');
            $people[] = array('id' => substr(md5(uniqid('', true)), 0, 10), 'name' => $name, 'hash' => $hash, 'created' => time(), 'last_login' => 0, 'logins' => 0);
            update_option(KGS_OPTION_PEOPLE, $people, false);
            return array('success', sprintf('%s was added. Their password is: %s — copy it now. It is stored in a one-way form and this page cannot show it again (you can always set a new one).', esc_html($name), '<code>' . esc_html($pass) . '</code>'));
        }
        foreach ($people as &$p) {
            if ((string) $p['id'] === $id) {
                $p['hash'] = $hash;
                $name = $p['name'];
                unset($p);
                update_option(KGS_OPTION_PEOPLE, $people, false);
                return array('success', sprintf('New password for %s: %s — copy it now. Their old password, and any browser still logged in with it, stopped working.', esc_html($name), '<code>' . esc_html($pass) . '</code>'));
            }
        }
        unset($p);
        return array('error', 'That person was not found.');
    }

    if ($action === 'remove') {
        $id = sanitize_key(wp_unslash(isset($_POST['kgs_id']) ? $_POST['kgs_id'] : ''));
        $name = '';
        foreach ($people as $i => $p) {
            if ((string) $p['id'] === $id) { $name = $p['name']; unset($people[$i]); }
        }
        if ($name === '') return array('error', 'That person was not found.');
        update_option(KGS_OPTION_PEOPLE, array_values($people), false);
        return array('success', sprintf('%s was removed. Their password no longer works, and any browser they were logged in on is logged out.', esc_html($name)));
    }

    if ($action === 'settings') {
        $s = kgs_settings();
        $slug = sanitize_title(wp_unslash(isset($_POST['kgs_slug']) ? $_POST['kgs_slug'] : ''));
        $s['slug']         = $slug !== '' ? $slug : 'sightings';
        $s['map_dir']      = trim(sanitize_text_field(wp_unslash(isset($_POST['kgs_map_dir']) ? $_POST['kgs_map_dir'] : 'map')), '/ ');
        foreach (array('show_planned', 'show_gone', 'show_address', 'show_notes') as $k) $s[$k] = empty($_POST['kgs_' . $k]) ? 0 : 1;
        $s['days']         = max(1, min(365, (int) (isset($_POST['kgs_days']) ? $_POST['kgs_days'] : 30)));
        update_option(KGS_OPTION_SETTINGS, $s, false);
        return array('success', 'Settings saved.');
    }
    return null;
}

function kgs_render_admin() {
    if (!current_user_can('manage_options')) return;
    $notice = kgs_admin_handle_post();
    $s      = kgs_settings();
    $people = kgs_people();
    $dir    = kgs_map_dir($s);
    $shown  = count(kgs_visible_placements($s));
    $url    = kgs_viewer_url();
    $fmt    = get_option('date_format') . ' ' . get_option('time_format');
    ?>
    <div class="wrap">
      <h1>KG Sightings <span style="font-size:12px;color:#777;">v<?php echo esc_html(KGS_VERSION); ?></span></h1>
      <?php if ($notice): ?>
        <div class="notice notice-<?php echo esc_attr($notice[0]); ?>"><p><?php echo wp_kses($notice[1], array('code' => array())); ?></p></div>
      <?php endif; ?>

      <p style="max-width:820px;">The view-only map is at <a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener"><code><?php echo esc_html($url); ?></code></a>.
        It shows the same pins as the private map but has no way to add, change or delete anything. Send a person that address and their own password — there is no username.</p>

      <?php if ($dir === ''): ?>
        <div class="notice notice-error inline"><p><strong>The private map folder was not found.</strong> This plugin looked for <code><?php echo esc_html(rtrim(ABSPATH, '/') . '/' . $s['map_dir']); ?></code>. Correct the folder name under “What viewers see” below.</p></div>
      <?php else: ?>
        <p style="color:#555;">Right now a viewer sees <strong><?php echo (int) $shown; ?></strong> pin<?php echo $shown === 1 ? '' : 's'; ?>.</p>
      <?php endif; ?>

      <h2>People</h2>
      <table class="widefat striped" style="max-width:980px;">
        <thead><tr><th>Name</th><th>Added</th><th>Last logged in</th><th>Logins</th><th style="width:420px;">Actions</th></tr></thead>
        <tbody>
        <?php if (!$people): ?>
          <tr><td colspan="5">Nobody yet. Add the first person below.</td></tr>
        <?php endif; ?>
        <?php foreach ($people as $p): ?>
          <tr>
            <td><strong><?php echo esc_html($p['name']); ?></strong></td>
            <td><?php echo esc_html(wp_date(get_option('date_format'), (int) $p['created'])); ?></td>
            <td><?php echo !empty($p['last_login']) ? esc_html(wp_date($fmt, (int) $p['last_login'])) : '<span style="color:#999;">never</span>'; ?></td>
            <td><?php echo (int) (isset($p['logins']) ? $p['logins'] : 0); ?></td>
            <td>
              <form method="post" style="display:inline-flex;gap:6px;align-items:center;">
                <?php wp_nonce_field('kgs_admin'); ?>
                <input type="hidden" name="kgs_action" value="reset">
                <input type="hidden" name="kgs_id" value="<?php echo esc_attr($p['id']); ?>">
                <input type="text" name="kgs_password" placeholder="new password" autocomplete="off" style="width:170px;">
                <button class="button">Set new password</button>
              </form>
              <form method="post" style="display:inline;" onsubmit="return confirm('Remove <?php echo esc_js($p['name']); ?>? Their password stops working straight away.');">
                <?php wp_nonce_field('kgs_admin'); ?>
                <input type="hidden" name="kgs_action" value="remove">
                <input type="hidden" name="kgs_id" value="<?php echo esc_attr($p['id']); ?>">
                <button class="button button-link-delete" style="margin-left:8px;">Remove</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>

      <h3 style="margin-top:22px;">Add a person</h3>
      <form method="post" style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap;max-width:980px;">
        <?php wp_nonce_field('kgs_admin'); ?>
        <input type="hidden" name="kgs_action" value="add">
        <label>Name (only you see this)<br><input type="text" name="kgs_name" class="regular-text" placeholder="Tim G" autocomplete="off" required></label>
        <label>Password (this is what they type)<br><input type="text" name="kgs_password" id="kgs-new-pass" class="regular-text" autocomplete="off" required minlength="6"></label>
        <button type="button" class="button" id="kgs-gen">Suggest one</button>
        <button class="button button-primary">Add person</button>
      </form>
      <p class="description" style="max-width:820px;">Each person needs a different password of at least 6 characters. The name is never shown to them and is not used to log in. Passwords are case-sensitive.</p>
      <script>
      document.getElementById('kgs-gen').addEventListener('click', function () {
        var words = ['mori','ghost','knock','drip','lace','tulip','bone','ember','hush','moth','vellum','candle','shade','wisp','hour','glass'];
        var pick = function () { var a = new Uint32Array(1); crypto.getRandomValues(a); return a[0]; };
        document.getElementById('kgs-new-pass').value = words[pick() % words.length] + '-' + words[pick() % words.length] + '-' + (100 + pick() % 900);
      });
      </script>

      <h2 style="margin-top:34px;">What viewers see</h2>
      <form method="post">
        <?php wp_nonce_field('kgs_admin'); ?>
        <input type="hidden" name="kgs_action" value="settings">
        <table class="form-table" role="presentation" style="max-width:980px;">
          <tr><th scope="row">Pins</th><td>
            <p>Placed pieces are always shown.</p>
            <label><input type="checkbox" name="kgs_show_planned" value="1" <?php checked($s['show_planned']); ?>> Also show planned spots (X pins)</label><br>
            <label><input type="checkbox" name="kgs_show_gone" value="1" <?php checked($s['show_gone']); ?>> Also show pieces marked “gone”</label>
          </td></tr>
          <tr><th scope="row">Details on each pin</th><td>
            <p>Title, piece type, date placed and photos are always shown.</p>
            <label><input type="checkbox" name="kgs_show_address" value="1" <?php checked($s['show_address']); ?>> Show the written address</label><br>
            <label><input type="checkbox" name="kgs_show_notes" value="1" <?php checked($s['show_notes']); ?>> Show your notes</label>
            <p class="description">The pin itself still sits at its real position on the map, whether or not the written address is shown.</p>
          </td></tr>
          <tr><th scope="row"><label for="kgs_days">A login lasts</label></th><td>
            <input type="number" id="kgs_days" name="kgs_days" min="1" max="365" value="<?php echo (int) $s['days']; ?>" style="width:80px;"> days on one browser, then the password is asked for again.
          </td></tr>
          <tr><th scope="row"><label for="kgs_slug">Address</label></th><td>
            <code><?php echo esc_html(home_url('/')); ?></code><input type="text" id="kgs_slug" name="kgs_slug" value="<?php echo esc_attr($s['slug']); ?>" style="width:160px;"><code>/</code>
            <p class="description">Changing this changes the link you have already sent to people.</p>
          </td></tr>
          <tr><th scope="row"><label for="kgs_map_dir">Private map folder</label></th><td>
            <code><?php echo esc_html(rtrim(ABSPATH, '/')); ?>/</code><input type="text" id="kgs_map_dir" name="kgs_map_dir" value="<?php echo esc_attr($s['map_dir']); ?>" style="width:160px;">
            <?php echo $dir !== '' ? '<span style="color:#1f7a3a;">found</span>' : '<span style="color:#b32d2e;">not found</span>'; ?>
          </td></tr>
        </table>
        <?php submit_button('Save settings'); ?>
      </form>

      <h2>One-time server setting</h2>
      <p style="max-width:820px;">In SiteGround Site Tools → Speed → Caching → Dynamic Cache → Exclude URLs, add <code>/<?php echo esc_html($s['slug']); ?>/*</code>. The page already asks not to be stored, and this makes sure of it.</p>
    </div>
    <?php
}
